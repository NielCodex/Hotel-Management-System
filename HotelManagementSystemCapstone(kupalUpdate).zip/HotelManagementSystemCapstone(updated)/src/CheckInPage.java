import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.ParseException;
import java.util.Date;
import static java.util.Locale.filter;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.mysql.cj.jdbc.Blob;
import java.awt.Color;
import java.awt.Font;
import static java.lang.Integer.sum;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
public class CheckInPage extends javax.swing.JFrame {

    /**
     * Creates new form CheckInPage
     */
    public CheckInPage() {
        initComponents();
    }
    
    Connection cont=null; 
    ResultSet rs;
    PreparedStatement pst;
    String sql;
    String path=null;
    String path2=null;
    byte[] userimage = null;
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        checknt = new javax.swing.JTextField();
        aids = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        contpers = new javax.swing.JTextField();
        roonum = new javax.swing.JTextField();
        bedt = new javax.swing.JTextField();
        roomt = new javax.swing.JTextField();
        paymeth = new javax.swing.JTextField();
        checknd = new javax.swing.JTextField();
        jTextField10 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        contnumb = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        emailaddd = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        residaddd = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        prices = new javax.swing.JTextField();
        paystats = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 0, 0));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel1.setText("CHECK-IN");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel1)
                .addContainerGap(747, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(10, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 990, 80));

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 990, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 990, 20));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Contact Person:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 130, 150, 20));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("Age:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 320, 130, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setText("CheckIn-Time");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 270, 150, 40));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setText("Room No.:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 100, 20));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setText("Bed Type:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 150, 20));
        getContentPane().add(checknt, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 310, 140, 30));
        getContentPane().add(aids, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 330, 220, 30));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setText("CheckIn-Date:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, 150, 20));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel10.setText("Room Type:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 150, 20));
        getContentPane().add(contpers, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 130, 220, 30));
        getContentPane().add(roonum, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 130, 140, 30));
        getContentPane().add(bedt, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 180, 140, 30));
        getContentPane().add(roomt, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 230, 140, 30));
        getContentPane().add(paymeth, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 380, 150, 30));
        getContentPane().add(checknd, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, 130, 30));
        getContentPane().add(jTextField10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, 130, 30));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setText("Contact No:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 180, 150, 20));
        getContentPane().add(contnumb, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 180, 220, 30));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel11.setText("Email Address:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 230, 150, 20));
        getContentPane().add(emailaddd, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 230, 220, 30));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setText("Residential Address:");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 280, 180, 20));
        getContentPane().add(residaddd, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 280, 220, 30));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel13.setText("Total Cost:");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 350, 100, 30));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel14.setText("Payment Method:");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 350, 180, 30));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel15.setText("Payment Status");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 350, 140, 30));

        prices.setForeground(new java.awt.Color(204, 0, 0));
        prices.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        getContentPane().add(prices, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 110, 30));
        getContentPane().add(paystats, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 380, 140, 30));

        jLabel28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/add.png"))); // NOI18N
        getContentPane().add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 440, 70, 110));

        jButton8.setBackground(new java.awt.Color(0, 153, 0));
        jButton8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setText("   Check-In");
        jButton8.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 470, 190, 50));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
              //Inserting data into database       
        String roomnum = roonum.getText(); 
        String bedtype = bedt.getText(); 
        String roomtype = roomt.getText();    
        String checkindate =  checknd.getText();        
        String checkintime =  checknt.getText();              
        String price2 =  prices.getText();        
        String paymentstats =  paystats.getText();         
        String paymentmethod =  paymeth.getText();        
        String contperson = contpers.getText();        
        String contnumber =  contnumb.getText();        
        String emailaddress =  emailaddd.getText();        
        String resdaress =  residaddd.getText();        
        String gender3 =  aids.getText();            
       


            try{
                Class.forName("com.mysql.cj.jdbc.Driver");
                cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/reservationdatabase","root","");
                pst = cont.prepareStatement("insert into reservationtable(room_number,bed_type,room_type,checkin_date,checkin_time,contact_person,contact_number,email_address,Residential_address,gender,totalprice,payment_stats,payment_method) values (?,?,?,?,?,?,?,?,?,?,?,?,?)");
            pst.setString(1, roomnum);
            pst.setString(2, bedtype);
            pst.setString(3, roomtype);
            pst.setString(4, checkindate);
            pst.setString(5, checkintime);                     
            pst.setString(6,contperson);
            pst.setString(7,contnumber);
            pst.setString(8,emailaddress);
            pst.setString(9,resdaress);
            pst.setString(10,gender3);
            pst.setString(11, price2);
            pst.setString(12,paymentstats);
            pst.setString(13,paymentmethod);
               
                 Icon icon = new javax.swing.ImageIcon(getClass().getResource("/Images/checked.png"));
                JOptionPane.showMessageDialog(this, "Room No."+roomnum+" Check-In Successfully","Hooray",JOptionPane.INFORMATION_MESSAGE,icon);
                pst.executeUpdate();
                

            } catch (ClassNotFoundException ex){
                Logger.getLogger(DashboardPage.class.getName()).log(Level.SEVERE, null, ex);

            } catch (SQLException ex) {
                Logger.getLogger(DashboardPage.class.getName()).log(Level.SEVERE, null, ex);
            }
      
            
         

      dispose();

      
      

    }//GEN-LAST:event_jButton8ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CheckInPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CheckInPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CheckInPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CheckInPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CheckInPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JTextField aids;
    public javax.swing.JTextField bedt;
    public javax.swing.JTextField checknd;
    public javax.swing.JTextField checknt;
    public javax.swing.JTextField contnumb;
    public javax.swing.JTextField contpers;
    public javax.swing.JTextField emailaddd;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField jTextField10;
    public javax.swing.JTextField paymeth;
    public javax.swing.JTextField paystats;
    public javax.swing.JTextField prices;
    public javax.swing.JTextField residaddd;
    public javax.swing.JTextField roomt;
    public javax.swing.JTextField roonum;
    // End of variables declaration//GEN-END:variables
}
