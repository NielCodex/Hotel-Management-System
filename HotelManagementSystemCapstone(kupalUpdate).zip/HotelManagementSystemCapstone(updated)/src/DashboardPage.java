
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.ParseException;
import java.util.Date;
import static java.util.Locale.filter;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.mysql.cj.jdbc.Blob;
import com.mysql.cj.xdevapi.Statement;
import java.awt.Color;
import java.awt.Font;
import static java.lang.Integer.sum;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;





public final class DashboardPage extends javax.swing.JFrame {

    static void addRowToJtable(Object[] object) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

   
   
  
    
     
    public DashboardPage() {
        initComponents();
        showDate();       
        showTime();
       
          
        
        jTableform.getColumnModel().getColumn(0).setPreferredWidth(2);
        jTableform.getColumnModel().getColumn(1).setPreferredWidth(100); 
        jTableform.getColumnModel().getColumn(2).setPreferredWidth(100);
        jTableform.getColumnModel().getColumn(3).setPreferredWidth(150); 
        jTableform.getColumnModel().getColumn(4).setPreferredWidth(150); 
        jTableform.getColumnModel().getColumn(5).setPreferredWidth(120);
        jTableform.getColumnModel().getColumn(6).setPreferredWidth(150);
        jTableform.getColumnModel().getColumn(7).setPreferredWidth(2); 
        jTableform.getColumnModel().getColumn(8).setPreferredWidth(100);
         
        reservationtab3.getColumnModel().getColumn(0).setPreferredWidth(1);
        reservationtab3.getColumnModel().getColumn(1).setPreferredWidth(80);
        reservationtab3.getColumnModel().getColumn(2).setPreferredWidth(100); 
        reservationtab3.getColumnModel().getColumn(3).setPreferredWidth(80);
        reservationtab3.getColumnModel().getColumn(4).setPreferredWidth(100); 
        reservationtab3.getColumnModel().getColumn(5).setPreferredWidth(100); 
        reservationtab3.getColumnModel().getColumn(6).setPreferredWidth(120);
        reservationtab3.getColumnModel().getColumn(7).setPreferredWidth(130);
        reservationtab3.getColumnModel().getColumn(8).setPreferredWidth(100); 
        reservationtab3.getColumnModel().getColumn(9).setPreferredWidth(100);
        reservationtab3.getColumnModel().getColumn(10).setPreferredWidth(100);
        reservationtab3.getColumnModel().getColumn(11).setPreferredWidth(100);
        reservationtab3.getColumnModel().getColumn(12).setPreferredWidth(100);
        reservationtab3.getColumnModel().getColumn(13).setPreferredWidth(130);
       
        reservationtab2.getColumnModel().getColumn(0).setPreferredWidth(1);
        reservationtab2.getColumnModel().getColumn(1).setPreferredWidth(80);
        reservationtab2.getColumnModel().getColumn(2).setPreferredWidth(100); 
        reservationtab2.getColumnModel().getColumn(3).setPreferredWidth(80);
        reservationtab2.getColumnModel().getColumn(4).setPreferredWidth(100); 
        reservationtab2.getColumnModel().getColumn(5).setPreferredWidth(100); 
        reservationtab2.getColumnModel().getColumn(6).setPreferredWidth(120);
        reservationtab2.getColumnModel().getColumn(7).setPreferredWidth(130);
        reservationtab2.getColumnModel().getColumn(8).setPreferredWidth(100); 
        reservationtab2.getColumnModel().getColumn(9).setPreferredWidth(100);
        reservationtab2.getColumnModel().getColumn(10).setPreferredWidth(100);
        reservationtab2.getColumnModel().getColumn(11).setPreferredWidth(100);
        reservationtab2.getColumnModel().getColumn(12).setPreferredWidth(100);
        reservationtab2.getColumnModel().getColumn(13).setPreferredWidth(130);
        
        reservationtab4.getColumnModel().getColumn(0).setPreferredWidth(20);
        reservationtab4.getColumnModel().getColumn(1).setPreferredWidth(80);
        reservationtab4.getColumnModel().getColumn(2).setPreferredWidth(100); 
        reservationtab4.getColumnModel().getColumn(3).setPreferredWidth(80);
        reservationtab4.getColumnModel().getColumn(4).setPreferredWidth(130); 
        reservationtab4.getColumnModel().getColumn(5).setPreferredWidth(130); 
        reservationtab4.getColumnModel().getColumn(6).setPreferredWidth(130);
        reservationtab4.getColumnModel().getColumn(7).setPreferredWidth(130);
        reservationtab4.getColumnModel().getColumn(8).setPreferredWidth(100); 
        reservationtab4.getColumnModel().getColumn(9).setPreferredWidth(100);
        reservationtab4.getColumnModel().getColumn(10).setPreferredWidth(100);
        reservationtab4.getColumnModel().getColumn(11).setPreferredWidth(70);
        reservationtab4.getColumnModel().getColumn(12).setPreferredWidth(100);
        reservationtab4.getColumnModel().getColumn(13).setPreferredWidth(130);
        
        reservationtab5.getColumnModel().getColumn(0).setPreferredWidth(0);
        reservationtab5.getColumnModel().getColumn(1).setPreferredWidth(400);
        reservationtab5.getColumnModel().getColumn(2).setPreferredWidth(400); 
        reservationtab5.getColumnModel().getColumn(3).setPreferredWidth(400);
        reservationtab5.getColumnModel().getColumn(4).setPreferredWidth(400);

        
        reservationtab6.getColumnModel().getColumn(0).setPreferredWidth(0);
        reservationtab6.getColumnModel().getColumn(1).setPreferredWidth(400);
        reservationtab6.getColumnModel().getColumn(2).setPreferredWidth(400); 
        reservationtab6.getColumnModel().getColumn(3).setPreferredWidth(500);

         reservationtab2.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 15));
         reservationtab2.getTableHeader().setOpaque(false);
         reservationtab2.getTableHeader().setBackground(new Color(0, 38, 130));
         reservationtab2.getTableHeader().setForeground(new Color(0,0,0));
         reservationtab2.setRowHeight(20);
        
         reservationtab3.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 15));
         reservationtab3.getTableHeader().setOpaque(false);
         reservationtab3.getTableHeader().setBackground(new Color(0, 38, 130));
         reservationtab3.getTableHeader().setForeground(new Color(0,0,0));
         reservationtab3.setRowHeight(20);
        
         reservationtab4.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 15));
         reservationtab4.getTableHeader().setOpaque(false);
         reservationtab4.getTableHeader().setBackground(new Color(0, 38, 130));
         reservationtab4.getTableHeader().setForeground(new Color(0,0,0));
         reservationtab4.setRowHeight(20);
             
         reservationtab5.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 15));
         reservationtab5.getTableHeader().setOpaque(false);
         reservationtab5.getTableHeader().setBackground(new Color(0, 38, 130));
         reservationtab5.getTableHeader().setForeground(new Color(0,0,0));
         reservationtab5.setRowHeight(20);
         
         jTableform.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 15));
         jTableform.getTableHeader().setOpaque(false);
         jTableform.getTableHeader().setBackground(new Color(0, 38, 130));
         jTableform.getTableHeader().setForeground(new Color(0,0,0));
         jTableform.setRowHeight(20);  
         
         reservationtab6.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 15));
         reservationtab6.getTableHeader().setOpaque(false);
         reservationtab6.getTableHeader().setBackground(new Color(0, 38, 130));
         reservationtab6.getTableHeader().setForeground(new Color(0,0,0));
         reservationtab6.setRowHeight(20);
       
     
    }   
    Connection cont=null; 
    ResultSet rs;
    PreparedStatement pst;
    String sql;
    String path=null;
    String path2=null;
    Statement stmt;
    byte[] userimage = null;
   


    
    
 
//Creating Live Date%Time
  public void showDate(){
      Date d = new Date();
      SimpleDateFormat s = new SimpleDateFormat("MM/dd/yyyy");
      String dat = s.format(d);
      jdate.setText(dat);   
      jdate2.setText(dat);
      jdate3.setText(dat);
      
     
  }
  public void showTime(){
      new Timer (0,new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
          Date d = new Date();
          SimpleDateFormat s = new SimpleDateFormat("h:mm:ss");
          String tim = s.format(d);
          jtime.setText(tim);         
          jtime3.setText(tim);         
          jtime4.setText(tim);
          }
      
      }).start();
 }
  
  
 
    public DashboardPage(String name){
    
    initComponents();
    
      jLabel13.setText(name);
      
    
    }
   CheckInPage jtRowData = new CheckInPage();
   CheckOutPage1 jtRowData1 = new CheckOutPage1(); 
   ManageRoom jtRowData2 = new ManageRoom();
   CheckInPage2 jtRowData3 = new CheckInPage2();

    @SuppressWarnings({"unchecked", "unused"})
    
  
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        jLabel42 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jButton12 = new javax.swing.JButton();
        jLabel29 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jLabel28 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel10 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabelroom5 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jLabelroom8 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jLabelroom6 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jLabelroom7 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jtime = new javax.swing.JLabel();
        jdate = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabelroom9 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabelroom12 = new javax.swing.JLabel();
        jPanel25 = new javax.swing.JPanel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabelroom13 = new javax.swing.JLabel();
        jPanel26 = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();
        jLabelroom14 = new javax.swing.JLabel();
        jLabel89 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jPanel31 = new javax.swing.JPanel();
        jLabel88 = new javax.swing.JLabel();
        jLabelroom15 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        reservationtab4 = new javax.swing.JTable();
        jLabel11 = new javax.swing.JLabel();
        jPanel27 = new javax.swing.JPanel();
        jButton20 = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        jButton22 = new javax.swing.JButton();
        jLabel35 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jLabel94 = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jLabel48 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        Gend1 = new javax.swing.JComboBox<>();
        jLabel67 = new javax.swing.JLabel();
        jPanel20 = new javax.swing.JPanel();
        jLabel68 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        ContPer1 = new javax.swing.JTextField();
        price1 = new javax.swing.JTextField();
        jLabel70 = new javax.swing.JLabel();
        BTYPE1 = new javax.swing.JComboBox<>();
        jLabel71 = new javax.swing.JLabel();
        PaymentM1 = new javax.swing.JComboBox<>();
        jLabel72 = new javax.swing.JLabel();
        RNO1 = new javax.swing.JComboBox<>();
        jdate3 = new javax.swing.JTextField();
        jLabel73 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        RTYPE1 = new javax.swing.JComboBox<>();
        PaymetS1 = new javax.swing.JComboBox<>();
        jLabel38 = new javax.swing.JLabel();
        jbsave1 = new javax.swing.JButton();
        jLabel76 = new javax.swing.JLabel();
        ResiAdd1 = new javax.swing.JTextField();
        CPN1 = new javax.swing.JTextField();
        jLabel79 = new javax.swing.JLabel();
        Emailadd1 = new javax.swing.JTextField();
        jLabel49 = new javax.swing.JLabel();
        jLabel80 = new javax.swing.JLabel();
        jtime4 = new javax.swing.JTextField();
        jScrollPane6 = new javax.swing.JScrollPane();
        reservationtab3 = new javax.swing.JTable();
        jPanel21 = new javax.swing.JPanel();
        jTextField2 = new javax.swing.JTextField();
        jPanel23 = new javax.swing.JPanel();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jLabel91 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel77 = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel46 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        Gend = new javax.swing.JComboBox<>();
        jLabel59 = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        jLabel92 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        ContPer = new javax.swing.JTextField();
        price = new javax.swing.JTextField();
        jLabel56 = new javax.swing.JLabel();
        BTYPE = new javax.swing.JComboBox<>();
        jLabel57 = new javax.swing.JLabel();
        PaymentM = new javax.swing.JComboBox<>();
        jLabel58 = new javax.swing.JLabel();
        RNO = new javax.swing.JComboBox<>();
        jdate2 = new javax.swing.JTextField();
        jLabel51 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        RTYPE = new javax.swing.JComboBox<>();
        PaymetS = new javax.swing.JComboBox<>();
        jLabel62 = new javax.swing.JLabel();
        ResiAdd = new javax.swing.JTextField();
        CPN = new javax.swing.JTextField();
        jLabel65 = new javax.swing.JLabel();
        Emailadd = new javax.swing.JTextField();
        jLabel47 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jtime3 = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        reservationtab2 = new javax.swing.JTable();
        jPanel7 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jPanel24 = new javax.swing.JPanel();
        jButton16 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jButton19 = new javax.swing.JButton();
        jLabel50 = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        Employee_ID = new javax.swing.JTextField();
        First_Name = new javax.swing.JTextField();
        Last_Name = new javax.swing.JTextField();
        EmpPosition = new javax.swing.JComboBox<>();
        EmpGender = new javax.swing.JComboBox<>();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jladdphoto = new javax.swing.JLabel();
        Add1 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        searcfield = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        empemail = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        empage = new javax.swing.JComboBox<>();
        jLabel33 = new javax.swing.JLabel();
        Phone_No1 = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        jladdphoto1 = new javax.swing.JLabel();
        Add = new javax.swing.JButton();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTableform = new javax.swing.JTable();
        jButton30 = new javax.swing.JButton();
        jLabel81 = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        jPanel28 = new javax.swing.JPanel();
        jPanel29 = new javax.swing.JPanel();
        jButton27 = new javax.swing.JButton();
        jButton28 = new javax.swing.JButton();
        jButton29 = new javax.swing.JButton();
        jScrollPane8 = new javax.swing.JScrollPane();
        reservationtab5 = new javax.swing.JTable();
        jScrollPane9 = new javax.swing.JScrollPane();
        reservationtab6 = new javax.swing.JTable();
        jPanel30 = new javax.swing.JPanel();
        jButton23 = new javax.swing.JButton();
        jButton25 = new javax.swing.JButton();
        jButton24 = new javax.swing.JButton();
        jButton26 = new javax.swing.JButton();
        jLabel83 = new javax.swing.JLabel();
        jLabel84 = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        jLabel85 = new javax.swing.JLabel();
        jLabel86 = new javax.swing.JLabel();
        jPanel32 = new javax.swing.JPanel();
        jLabel95 = new javax.swing.JLabel();
        jLabel100 = new javax.swing.JLabel();
        jLabel101 = new javax.swing.JLabel();
        jLabel102 = new javax.swing.JLabel();
        jLabel97 = new javax.swing.JLabel();
        jLabel96 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setMinimumSize(new java.awt.Dimension(1926, 967));
        setPreferredSize(new java.awt.Dimension(1926, 967));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(51, 51, 51));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/add (1).png"))); // NOI18N
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 710, -1, -1));

        jButton9.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton9.setText("      Add Empolyee");
        jButton9.setBorder(null);
        jButton9.setBorderPainted(false);
        jButton9.setFocusable(false);
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 700, 250, 50));

        jLabel42.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/reserved.png"))); // NOI18N
        jPanel2.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 570, -1, -1));
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 520, -1, -1));

        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton6.setText("Check-In");
        jButton6.setBorder(null);
        jButton6.setBorderPainted(false);
        jButton6.setFocusable(false);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 560, 250, 50));

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/bed_11865489.png"))); // NOI18N
        jPanel2.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 500, -1, -1));

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/project-management (1).png"))); // NOI18N
        jPanel2.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 420, 40, 50));

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton1.setText("   Check-Out ");
        jButton1.setBorder(null);
        jButton1.setBorderPainted(false);
        jButton1.setFocusable(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 420, 250, 50));

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/dashboard.png"))); // NOI18N
        jPanel2.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 360, -1, -1));

        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton2.setText(" Dashboard");
        jButton2.setBorder(null);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 350, 250, 50));

        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton3.setText("    Booked Room");
        jButton3.setBorder(null);
        jButton3.setBorderPainted(false);
        jButton3.setFocusable(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 490, 250, 50));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel13.setText("ADMINISTRATOR");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 160, 200, 40));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/online-booking_3223150.png"))); // NOI18N
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 640, -1, -1));

        jButton12.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton12.setText("     Manage Room");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 630, 250, 50));

        jLabel29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/interior-design.png"))); // NOI18N
        jPanel2.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 780, -1, -1));

        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton5.setText("   Room Details");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 770, 250, 50));

        jLabel28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/leave.png"))); // NOI18N
        jPanel2.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 850, 100, -1));

        jButton8.setBackground(new java.awt.Color(204, 51, 0));
        jButton8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setText("       LOGOUT");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 840, 170, 50));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Online.png"))); // NOI18N
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 310, 1080));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 310, 1080));

        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel8.setBackground(new java.awt.Color(153, 204, 255));
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("OCCUPIED ROOMS");
        jPanel8.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 20, -1, -1));

        jLabelroom5.setFont(new java.awt.Font("Segoe UI", 0, 58)); // NOI18N
        jLabelroom5.setForeground(new java.awt.Color(255, 255, 255));
        jLabelroom5.setText("0");
        jPanel8.add(jLabelroom5, new org.netbeans.lib.awtextra.AbsoluteConstraints(259, 71, 140, 70));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gifimage/output-onlinegiftools.gif"))); // NOI18N
        jPanel8.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, -20, 240, 240));

        jPanel10.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 480, 410, 200));

        jPanel13.setBackground(new java.awt.Color(255, 204, 102));
        jPanel13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("CHECK-IN");
        jPanel13.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(258, 34, -1, -1));

        jLabelroom8.setFont(new java.awt.Font("Segoe UI", 0, 58)); // NOI18N
        jLabelroom8.setForeground(new java.awt.Color(255, 255, 255));
        jLabelroom8.setText("0");
        jPanel13.add(jLabelroom8, new org.netbeans.lib.awtextra.AbsoluteConstraints(289, 71, 130, 70));

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gifimage/com-resize-unscreen_1.gif"))); // NOI18N
        jPanel13.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 200, -1));

        jPanel10.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 480, 440, 200));

        jPanel11.setBackground(new java.awt.Color(153, 153, 255));
        jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("TOTAL ROOMS");
        jPanel11.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(218, 28, -1, -1));

        jLabelroom6.setFont(new java.awt.Font("Segoe UI", 0, 58)); // NOI18N
        jLabelroom6.setForeground(new java.awt.Color(255, 255, 255));
        jLabelroom6.setText("15");
        jPanel11.add(jLabelroom6, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 60, 140, 70));

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gifimage/com-resize-unscreen (8).gif"))); // NOI18N
        jPanel11.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jPanel10.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 240, 440, 200));

        jPanel12.setBackground(new java.awt.Color(255, 153, 153));
        jPanel12.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jPanel12.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(367, 28, -1, -1));

        jLabelroom7.setFont(new java.awt.Font("Segoe UI", 0, 58)); // NOI18N
        jLabelroom7.setForeground(new java.awt.Color(255, 255, 255));
        jLabelroom7.setText("0");
        jPanel12.add(jLabelroom7, new org.netbeans.lib.awtextra.AbsoluteConstraints(267, 59, 130, -1));

        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gifimage/output-onlinegiftools (1).gif"))); // NOI18N
        jPanel12.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 37, -1, -1));

        jLabel24.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("BOOKED ROOMS");
        jPanel12.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(204, 28, -1, -1));

        jPanel10.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 240, 410, 200));

        jLabel43.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/clock.png"))); // NOI18N
        jPanel10.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(1320, 180, 50, 60));

        jLabel44.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/calendar.png"))); // NOI18N
        jPanel10.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(1320, 130, 50, 60));

        jtime.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jtime.setText("Time");
        jPanel10.add(jtime, new org.netbeans.lib.awtextra.AbsoluteConstraints(1370, 200, -1, -1));

        jdate.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jdate.setText("Date");
        jPanel10.add(jdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(1370, 150, -1, -1));

        jPanel4.setBackground(new java.awt.Color(255, 102, 102));

        jLabel34.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gifimage/com-resize-unscreen (2).gif"))); // NOI18N

        jLabel27.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(255, 255, 255));
        jLabel27.setText("TODAY'S INCOME");

        jLabelroom9.setFont(new java.awt.Font("Segoe UI", 0, 58)); // NOI18N
        jLabelroom9.setForeground(new java.awt.Color(255, 255, 255));
        jLabelroom9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelroom9.setText("0");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                        .addComponent(jLabel27)
                        .addGap(38, 38, 38))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelroom9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(21, 21, 21))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel27)
                        .addGap(39, 39, 39)
                        .addComponent(jLabelroom9, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel34, javax.swing.GroupLayout.DEFAULT_SIZE, 162, Short.MAX_VALUE)
                        .addGap(19, 19, 19))))
        );

        jPanel10.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 240, 410, 200));

        jPanel9.setBackground(new java.awt.Color(153, 51, 255));

        jLabel36.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gifimage/com-resize-unscreen (3).gif"))); // NOI18N

        jLabel37.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 255, 255));
        jLabel37.setText("TOTAL GUEST");

        jLabelroom12.setFont(new java.awt.Font("Segoe UI", 0, 58)); // NOI18N
        jLabelroom12.setForeground(new java.awt.Color(255, 255, 255));
        jLabelroom12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelroom12.setText("0");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelroom12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(21, 21, 21))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 54, Short.MAX_VALUE)
                        .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38))))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel37)
                        .addGap(39, 39, 39)
                        .addComponent(jLabelroom12, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel36, javax.swing.GroupLayout.DEFAULT_SIZE, 162, Short.MAX_VALUE)
                        .addGap(19, 19, 19))))
        );

        jPanel10.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 480, 410, 200));

        jPanel25.setBackground(new java.awt.Color(0, 153, 255));

        jLabel39.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gifimage/com-resize-unscreen (9).gif"))); // NOI18N

        jLabel40.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setText("Dirty Rooms");

        jLabelroom13.setFont(new java.awt.Font("Segoe UI", 0, 58)); // NOI18N
        jLabelroom13.setForeground(new java.awt.Color(255, 255, 255));
        jLabelroom13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelroom13.setText("0");

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelroom13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(21, 21, 21))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel25Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 84, Short.MAX_VALUE)
                        .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38))))
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addComponent(jLabel40)
                        .addGap(39, 39, 39)
                        .addComponent(jLabelroom13, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addComponent(jLabel39, javax.swing.GroupLayout.DEFAULT_SIZE, 162, Short.MAX_VALUE)
                        .addGap(19, 19, 19))))
        );

        jPanel10.add(jPanel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 720, 440, 200));

        jPanel26.setBackground(new java.awt.Color(0, 204, 204));

        jLabel41.setForeground(new java.awt.Color(0, 204, 204));
        jLabel41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gifimage/com-resize-unscreen (6).gif"))); // NOI18N

        jLabelroom14.setFont(new java.awt.Font("Segoe UI", 0, 58)); // NOI18N
        jLabelroom14.setForeground(new java.awt.Color(255, 255, 255));
        jLabelroom14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelroom14.setText("0");

        jLabel89.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel89.setForeground(new java.awt.Color(255, 255, 255));
        jLabel89.setText("Total Check-Out");

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel26Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelroom14, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
                        .addGap(21, 21, 21))
                    .addGroup(jPanel26Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(jLabel89, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel26Layout.createSequentialGroup()
                        .addComponent(jLabel89)
                        .addGap(39, 39, 39)
                        .addComponent(jLabelroom14, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 28, Short.MAX_VALUE))
                    .addComponent(jLabel41, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(19, 19, 19))
        );

        jPanel10.add(jPanel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 720, 410, 200));

        jLabel30.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/GL TRAVELODGE (1).png"))); // NOI18N
        jPanel10.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 1620, 100));

        jPanel31.setBackground(new java.awt.Color(102, 255, 102));

        jLabel88.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gifimage/output-onlinegiftools (2).gif"))); // NOI18N

        jLabelroom15.setFont(new java.awt.Font("Segoe UI", 0, 58)); // NOI18N
        jLabelroom15.setForeground(new java.awt.Color(255, 255, 255));
        jLabelroom15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelroom15.setText("0");

        jLabel45.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(255, 255, 255));
        jLabel45.setText("Total Employees");

        javax.swing.GroupLayout jPanel31Layout = new javax.swing.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel88, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelroom15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(21, 21, 21))
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(38, Short.MAX_VALUE))))
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addComponent(jLabel45)
                        .addGap(39, 39, 39)
                        .addComponent(jLabelroom15, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addComponent(jLabel88, javax.swing.GroupLayout.DEFAULT_SIZE, 162, Short.MAX_VALUE)
                        .addGap(19, 19, 19))))
        );

        jPanel10.add(jPanel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 720, 410, 200));

        jLabel90.setFont(new java.awt.Font("Segoe UI", 3, 48)); // NOI18N
        jLabel90.setText("DASHBOARD");
        jPanel10.add(jLabel90, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 170, -1, -1));

        jLabel64.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/fffff.png"))); // NOI18N
        jPanel10.add(jLabel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 1620, 860));

        jTabbedPane1.addTab("tab1", jPanel10);

        jPanel18.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        reservationtab4.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        reservationtab4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Room No.", "Bed Type", "Room Type", "CheckOut - Date", "CheckIn - Time", "CheckOut - Time", "Contact person", "Contact Number", "Email Address", "Residential Address", "Gender", "Total Cost", "Payment Status", "Payment Method"
            }
        ));
        reservationtab4.setRowHeight(30);
        reservationtab4.setShowVerticalLines(true);
        reservationtab4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                reservationtab4MouseClicked(evt);
            }
        });
        jScrollPane7.setViewportView(reservationtab4);

        jPanel18.add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 1590, 670));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 3, 48)); // NOI18N
        jLabel11.setText("CHECK-OUT ");
        jPanel18.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, -1, -1));

        jPanel27.setBackground(new java.awt.Color(255, 255, 255));
        jPanel27.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jPanel27.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton20.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton20.setForeground(new java.awt.Color(255, 255, 255));
        jButton20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/delete.png"))); // NOI18N
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });
        jPanel27.add(jButton20, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 50, 40));

        jButton21.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton21.setForeground(new java.awt.Color(255, 255, 255));
        jButton21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/refresh-button.png"))); // NOI18N
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });
        jPanel27.add(jButton21, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, 49, 40));

        jButton22.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton22.setForeground(new java.awt.Color(255, 255, 255));
        jButton22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/rubber.png"))); // NOI18N
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });
        jPanel27.add(jButton22, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, 49, 40));

        jPanel18.add(jPanel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(1430, 140, 170, 60));

        jLabel35.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/GL TRAVELODGE (1).png"))); // NOI18N
        jPanel18.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1600, 110));

        jLabel63.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/fffff.png"))); // NOI18N
        jPanel18.add(jLabel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 1620, 860));

        jTabbedPane1.addTab("tab5", jPanel18);

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel14.setBackground(new java.awt.Color(255, 255, 255));
        jPanel14.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                jPanel14AncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jPanel14.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel94.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/search.png"))); // NOI18N
        jPanel14.add(jLabel94, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 710, -1, 40));

        jPanel15.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel14.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 1600, 10));

        jLabel48.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel48.setText("Residential Address:");
        jPanel14.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 440, -1, -1));

        jLabel55.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel55.setText("Payment Method:");
        jPanel14.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 560, -1, -1));

        Gend1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        Gend1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));
        Gend1.setBorder(null);
        Gend1.setOpaque(true);
        jPanel14.add(Gend1, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 550, 100, 50));

        jLabel67.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel67.setText("Gender:");
        jPanel14.add(jLabel67, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 560, -1, -1));

        jPanel20.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel14.add(jPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 160, 10, 520));

        jLabel68.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel68.setText("Customer Details:");
        jPanel14.add(jLabel68, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 110, -1, 50));

        jLabel69.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel69.setText("Contact Person:");
        jPanel14.add(jLabel69, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 160, -1, -1));

        ContPer1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        ContPer1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ContPer1ActionPerformed(evt);
            }
        });
        jPanel14.add(ContPer1, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 280, 490, 55));

        price1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        price1.setForeground(new java.awt.Color(204, 0, 0));
        price1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        price1.setSelectionColor(new java.awt.Color(51, 255, 51));
        price1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                price1ActionPerformed(evt);
            }
        });
        price1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                price1KeyPressed(evt);
            }
        });
        jPanel14.add(price1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 590, 190, 55));

        jLabel70.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel70.setText("Bed Type:");
        jPanel14.add(jLabel70, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, -1, -1));

        BTYPE1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        BTYPE1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Family Room", "Standard Room" }));
        BTYPE1.setBorder(null);
        BTYPE1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTYPE1ActionPerformed(evt);
            }
        });
        jPanel14.add(BTYPE1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 250, 170, 60));

        jLabel71.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel71.setText("Room Type:");
        jPanel14.add(jLabel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 350, -1, -1));

        PaymentM1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        PaymentM1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "G-Cash", "Cash", "Bank Transfer" }));
        PaymentM1.setBorder(null);
        PaymentM1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PaymentM1ActionPerformed(evt);
            }
        });
        jPanel14.add(PaymentM1, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 590, 160, 60));

        jLabel72.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel72.setText("Room No.");
        jPanel14.add(jLabel72, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, -1, -1));

        RNO1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        RNO1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "101", "102", "103", "104", "105", "106", "107", "108", " " }));
        RNO1.setBorder(null);
        RNO1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RNO1ActionPerformed(evt);
            }
        });
        jPanel14.add(RNO1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 170, 170, 60));

        jdate3.setEditable(false);
        jdate3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jdate3.setForeground(new java.awt.Color(0, 0, 204));
        jdate3.setText("MM-DD-YYYY");
        jdate3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jdate3ActionPerformed(evt);
            }
        });
        jPanel14.add(jdate3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 460, 240, 55));

        jLabel73.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel73.setForeground(new java.awt.Color(0, 0, 204));
        jLabel73.setText("Booked Room Details:");
        jPanel14.add(jLabel73, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, -1, 50));

        jLabel74.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel74.setText("Total Cost:");
        jPanel14.add(jLabel74, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 560, -1, -1));

        jLabel75.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel75.setText("Payment Status:");
        jPanel14.add(jLabel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 560, -1, -1));

        RTYPE1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        RTYPE1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AC", "Non-AC" }));
        RTYPE1.setBorder(null);
        RTYPE1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RTYPE1ActionPerformed(evt);
            }
        });
        jPanel14.add(RTYPE1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 340, 170, 60));

        PaymetS1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        PaymetS1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Fully-paid", "Not Fully-paid", "Pending" }));
        PaymetS1.setBorder(null);
        PaymetS1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PaymetS1ActionPerformed(evt);
            }
        });
        jPanel14.add(PaymetS1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 590, 160, 60));

        jLabel38.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/check-out_1.png"))); // NOI18N
        jPanel14.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 600, 50, 100));

        jbsave1.setBackground(new java.awt.Color(255, 0, 0));
        jbsave1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jbsave1.setForeground(new java.awt.Color(255, 255, 255));
        jbsave1.setText("       Cancel Booking");
        jbsave1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jbsave1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbsave1ActionPerformed(evt);
            }
        });
        jPanel14.add(jbsave1, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 620, 190, 50));

        jLabel76.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel76.setText("CheckIn-Date");
        jPanel14.add(jLabel76, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 420, -1, -1));

        ResiAdd1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        ResiAdd1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResiAdd1ActionPerformed(evt);
            }
        });
        jPanel14.add(ResiAdd1, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 470, 490, 55));

        CPN1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        CPN1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CPN1ActionPerformed(evt);
            }
        });
        jPanel14.add(CPN1, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 190, 490, 55));

        jLabel79.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel79.setText("Contact No:");
        jPanel14.add(jLabel79, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 250, -1, -1));

        Emailadd1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        Emailadd1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Emailadd1ActionPerformed(evt);
            }
        });
        jPanel14.add(Emailadd1, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 370, 490, 55));

        jLabel49.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel49.setText("Email Address:");
        jPanel14.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 340, -1, -1));

        jLabel80.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel80.setText("CheckIn-Time");
        jPanel14.add(jLabel80, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 420, -1, -1));

        jtime4.setEditable(false);
        jtime4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jtime4.setForeground(new java.awt.Color(0, 153, 51));
        jtime4.setText("12:00");
        jtime4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtime4ActionPerformed(evt);
            }
        });
        jPanel14.add(jtime4, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 460, 180, 55));

        reservationtab3.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        reservationtab3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Room No.", "Bed Type", "Room Type", "BookIn - Date", "BookIn - Time", "Contact person", "Contact Number", "Email Address", "Residential Address", "Gender", "Total Cost", "Payment Status", "Payment Method"
            }
        ));
        reservationtab3.setRowHeight(30);
        reservationtab3.setShowVerticalLines(true);
        reservationtab3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                reservationtab3MouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(reservationtab3);

        jPanel14.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 750, 1590, 450));

        jPanel21.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel14.add(jPanel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 680, 1600, 10));

        jTextField2.setText("Room No.");
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        jTextField2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField2KeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField2KeyReleased(evt);
            }
        });
        jPanel14.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 710, 160, 40));

        jPanel23.setBackground(new java.awt.Color(255, 255, 255));
        jPanel23.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton14.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton14.setForeground(new java.awt.Color(255, 255, 255));
        jButton14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/delete.png"))); // NOI18N
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });
        jPanel23.add(jButton14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 50, 40));

        jButton15.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton15.setForeground(new java.awt.Color(255, 255, 255));
        jButton15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/refresh-button.png"))); // NOI18N
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });
        jPanel23.add(jButton15, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, 49, 40));

        jButton18.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton18.setForeground(new java.awt.Color(255, 255, 255));
        jButton18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/rubber.png"))); // NOI18N
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });
        jPanel23.add(jButton18, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, 49, 40));

        jPanel14.add(jPanel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(1360, 690, 230, 60));

        jLabel91.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/search.png"))); // NOI18N
        jPanel14.add(jLabel91, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 710, -1, 40));

        jLabel31.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/GL TRAVELODGE (1).png"))); // NOI18N
        jPanel14.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1620, -1));

        jLabel77.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/fffff.png"))); // NOI18N
        jPanel14.add(jLabel77, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 1620, 860));

        jLabel93.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/search.png"))); // NOI18N
        jPanel14.add(jLabel93, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 710, -1, 40));

        jPanel3.add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1603, 1080));

        jTabbedPane1.addTab("tab5", jPanel3);

        jPanel17.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1669, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 436, Short.MAX_VALUE)
        );

        jPanel17.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(2616, 22, -1, 436));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                jPanel5AncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        jPanel5.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 1600, 10));

        jLabel46.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel46.setText("Residential Address:");
        jPanel5.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 440, -1, -1));

        jLabel52.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel52.setText("Payment Method:");
        jPanel5.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 560, -1, -1));

        Gend.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        Gend.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));
        Gend.setBorder(null);
        Gend.setOpaque(true);
        jPanel5.add(Gend, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 550, 100, 50));

        jLabel59.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel59.setText("Gender:");
        jPanel5.add(jLabel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 560, -1, -1));

        jPanel19.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 520, Short.MAX_VALUE)
        );

        jPanel5.add(jPanel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 160, 10, 520));

        jLabel92.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/search.png"))); // NOI18N
        jPanel5.add(jLabel92, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 710, -1, 40));

        jLabel53.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel53.setText("Customer Details:");
        jPanel5.add(jLabel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 110, -1, 50));

        jLabel54.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel54.setText("Contact Person:");
        jPanel5.add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 160, -1, -1));

        ContPer.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        ContPer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ContPerActionPerformed(evt);
            }
        });
        jPanel5.add(ContPer, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 280, 490, 55));

        price.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        price.setForeground(new java.awt.Color(204, 0, 0));
        price.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        price.setSelectionColor(new java.awt.Color(51, 255, 51));
        price.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                priceActionPerformed(evt);
            }
        });
        price.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                priceKeyPressed(evt);
            }
        });
        jPanel5.add(price, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 590, 190, 55));

        jLabel56.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel56.setText("Bed Type:");
        jPanel5.add(jLabel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, -1, -1));

        BTYPE.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        BTYPE.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Family Room", "Standard Room" }));
        BTYPE.setBorder(null);
        BTYPE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTYPEActionPerformed(evt);
            }
        });
        jPanel5.add(BTYPE, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 250, 170, 60));

        jLabel57.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel57.setText("Room Type:");
        jPanel5.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 350, -1, -1));

        PaymentM.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        PaymentM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "G-Cash", "Cash", "Bank Transfer" }));
        PaymentM.setBorder(null);
        PaymentM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PaymentMActionPerformed(evt);
            }
        });
        jPanel5.add(PaymentM, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 590, 160, 60));

        jLabel58.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel58.setText("Room No.");
        jPanel5.add(jLabel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, -1, -1));

        RNO.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        RNO.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "101", "102", "103", "104", "105", "106", "107", "108", " " }));
        RNO.setBorder(null);
        RNO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RNOActionPerformed(evt);
            }
        });
        RNO.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                RNOKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                RNOKeyReleased(evt);
            }
        });
        jPanel5.add(RNO, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 170, 170, 60));

        jdate2.setEditable(false);
        jdate2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jdate2.setForeground(new java.awt.Color(0, 0, 204));
        jdate2.setText("MM-DD-YYYY");
        jdate2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jdate2ActionPerformed(evt);
            }
        });
        jPanel5.add(jdate2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 460, 240, 55));

        jLabel51.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel51.setForeground(new java.awt.Color(0, 204, 51));
        jLabel51.setText("Check-In Room Details:");
        jPanel5.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, -1, 50));

        jLabel60.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel60.setText("Total Cost:");
        jPanel5.add(jLabel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 560, -1, -1));

        jLabel61.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel61.setText("Payment Status:");
        jPanel5.add(jLabel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 560, -1, -1));

        RTYPE.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        RTYPE.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AC", "Non-AC" }));
        RTYPE.setBorder(null);
        RTYPE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RTYPEActionPerformed(evt);
            }
        });
        jPanel5.add(RTYPE, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 340, 170, 60));

        PaymetS.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        PaymetS.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Fully-paid", "Not Fully-paid", "Pending" }));
        PaymetS.setBorder(null);
        PaymetS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PaymetSActionPerformed(evt);
            }
        });
        jPanel5.add(PaymetS, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 590, 160, 60));

        jLabel62.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel62.setText("CheckIn-Date");
        jPanel5.add(jLabel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 420, -1, -1));

        ResiAdd.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        ResiAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResiAddActionPerformed(evt);
            }
        });
        jPanel5.add(ResiAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 470, 490, 55));

        CPN.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        CPN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CPNActionPerformed(evt);
            }
        });
        jPanel5.add(CPN, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 190, 490, 55));

        jLabel65.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel65.setText("Contact No:");
        jPanel5.add(jLabel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 250, -1, -1));

        Emailadd.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        Emailadd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmailaddActionPerformed(evt);
            }
        });
        jPanel5.add(Emailadd, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 370, 490, 55));

        jLabel47.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel47.setText("Email Address:");
        jPanel5.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 340, -1, -1));

        jLabel66.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel66.setText("CheckIn-Time");
        jPanel5.add(jLabel66, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 420, -1, -1));

        jtime3.setEditable(false);
        jtime3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jtime3.setForeground(new java.awt.Color(0, 153, 51));
        jtime3.setText("12:00");
        jtime3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtime3ActionPerformed(evt);
            }
        });
        jPanel5.add(jtime3, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 460, 180, 55));

        reservationtab2.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        reservationtab2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Room No.", "Bed Type", "Room Type", "Checkin - Date", "Check-In Time", "Contact person", "Contact Number", "Email Address", "Residential Address", "Gender", "Total Cost", "Payment Status", "Payment Method"
            }
        ));
        reservationtab2.setRowHeight(30);
        reservationtab2.setShowVerticalLines(true);
        reservationtab2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                reservationtab2MouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(reservationtab2);

        jPanel5.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 750, 1590, 450));

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1600, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        jPanel5.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 680, 1600, 10));

        jTextField1.setText("Room No.");
        jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField1KeyReleased(evt);
            }
        });
        jPanel5.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 710, 160, 40));

        jPanel24.setBackground(new java.awt.Color(204, 204, 255));
        jPanel24.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton16.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton16.setForeground(new java.awt.Color(255, 255, 255));
        jButton16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/delete.png"))); // NOI18N
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });
        jPanel24.add(jButton16, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 50, 40));

        jButton17.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton17.setForeground(new java.awt.Color(255, 255, 255));
        jButton17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/refresh-button.png"))); // NOI18N
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });
        jPanel24.add(jButton17, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, 49, 40));

        jButton19.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton19.setForeground(new java.awt.Color(255, 255, 255));
        jButton19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/rubber.png"))); // NOI18N
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });
        jPanel24.add(jButton19, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, 49, 40));

        jPanel5.add(jPanel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(1360, 700, 230, 50));

        jLabel50.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/GL TRAVELODGE (1).png"))); // NOI18N
        jPanel5.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1620, -1));

        jLabel78.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/fffff.png"))); // NOI18N
        jPanel5.add(jLabel78, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 1620, 860));

        jPanel17.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1603, 1080));

        jTabbedPane1.addTab("tab4", jPanel17);

        jPanel16.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel22.setBackground(new java.awt.Color(255, 255, 255));
        jPanel22.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setText("Employee ID No:");
        jPanel22.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 75, -1, 40));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel4.setText("First Name:");
        jPanel22.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel5.setText("Last Name:");
        jPanel22.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel6.setText("Gender:");
        jPanel22.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel7.setText("Age:");
        jPanel22.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 190, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel8.setText("Email:");
        jPanel22.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, -1, 40));

        Employee_ID.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        Employee_ID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Employee_IDActionPerformed(evt);
            }
        });
        jPanel22.add(Employee_ID, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 80, 300, 40));

        First_Name.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jPanel22.add(First_Name, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 130, 300, 40));

        Last_Name.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        Last_Name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Last_NameActionPerformed(evt);
            }
        });
        jPanel22.add(Last_Name, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 180, 300, 40));

        EmpPosition.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        EmpPosition.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Housekeeping", "FrontDesk Cashier" }));
        EmpPosition.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmpPositionActionPerformed(evt);
            }
        });
        jPanel22.add(EmpPosition, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 230, 300, 40));

        EmpGender.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        EmpGender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female", "" }));
        EmpGender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmpGenderActionPerformed(evt);
            }
        });
        jPanel22.add(EmpGender, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 280, 300, 40));

        jButton10.setBackground(new java.awt.Color(153, 0, 0));
        jButton10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton10.setForeground(new java.awt.Color(255, 255, 255));
        jButton10.setText("Delete");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel22.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 350, 200, 50));

        jButton11.setBackground(new java.awt.Color(0, 102, 0));
        jButton11.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton11.setForeground(new java.awt.Color(255, 255, 255));
        jButton11.setText("Update");
        jButton11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton11MouseClicked(evt);
            }
        });
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel22.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 350, 200, 50));

        jladdphoto.setBackground(new java.awt.Color(204, 204, 204));
        jladdphoto.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        jladdphoto.setOpaque(true);
        jPanel22.add(jladdphoto, new org.netbeans.lib.awtextra.AbsoluteConstraints(1240, 50, 220, 240));

        Add1.setBackground(new java.awt.Color(0, 0, 102));
        Add1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        Add1.setForeground(new java.awt.Color(255, 255, 255));
        Add1.setText("Add Member");
        Add1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Add1ActionPerformed(evt);
            }
        });
        jPanel22.add(Add1, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 350, 200, 50));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel9.setText("Choose Picture");
        jPanel22.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(1300, 30, -1, -1));

        searcfield.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        searcfield.setText("Search.....");
        searcfield.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searcfieldActionPerformed(evt);
            }
        });
        searcfield.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searcfieldKeyReleased(evt);
            }
        });
        jPanel22.add(searcfield, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 250, 40));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel10.setText("Date of Birth:");
        jPanel22.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 140, -1, 30));

        empemail.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jPanel22.add(empemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 230, 300, 40));

        jLabel32.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel32.setText("Position:");
        jPanel22.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 240, -1, -1));

        empage.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        empage.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-Select-", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "100" }));
        jPanel22.add(empage, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 180, 300, 40));

        jLabel33.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel33.setText("Phone No.:");
        jPanel22.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 90, -1, 30));

        Phone_No1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        Phone_No1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Phone_No1ActionPerformed(evt);
            }
        });
        jPanel22.add(Phone_No1, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 80, 300, 40));

        jButton4.setBackground(new java.awt.Color(204, 0, 102));
        jButton4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Clear");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel22.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 350, 200, 50));

        jladdphoto1.setBackground(new java.awt.Color(204, 204, 204));
        jladdphoto1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        jladdphoto1.setOpaque(true);
        jPanel22.add(jladdphoto1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1240, 50, 220, 240));

        Add.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        Add.setText("Upload Image..");
        Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddActionPerformed(evt);
            }
        });
        jPanel22.add(Add, new org.netbeans.lib.awtextra.AbsoluteConstraints(1240, 290, 220, 40));

        jDateChooser1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jPanel22.add(jDateChooser1, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 130, 300, 40));

        jPanel16.add(jPanel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(14, 529, 1560, 560));

        jTableform.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        jTableform.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No.", "Employee Id No", "First Name", "Last Name", "Email", "Gender", "Phone No.", "Date of Birth", "Age", "Position", "ID Picture"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTableform.setFocusable(false);
        jTableform.setGridColor(new java.awt.Color(0, 0, 0));
        jTableform.setRowHeight(30);
        jTableform.setSelectionBackground(new java.awt.Color(102, 255, 0));
        jTableform.setSelectionForeground(new java.awt.Color(255, 255, 255));
        jTableform.setShowVerticalLines(true);
        jTableform.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableformMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTableform);

        jPanel16.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(14, 27, 1560, 456));

        jButton30.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton30.setForeground(new java.awt.Color(255, 255, 255));
        jButton30.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/refresh-button.png"))); // NOI18N
        jButton30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton30ActionPerformed(evt);
            }
        });
        jPanel16.add(jButton30, new org.netbeans.lib.awtextra.AbsoluteConstraints(1520, 490, 49, 50));

        jLabel81.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/fffff.png"))); // NOI18N
        jPanel16.add(jLabel81, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 690, 1620, 1210));

        jLabel82.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/fffff.png"))); // NOI18N
        jPanel16.add(jLabel82, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -170, 1620, 1210));

        jTabbedPane1.addTab("tab3", jPanel16);

        jPanel28.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel29.setBackground(new java.awt.Color(255, 255, 255));
        jPanel29.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/delete.png"))); // NOI18N
        jButton27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton27ActionPerformed(evt);
            }
        });
        jPanel29.add(jButton27, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, 50, 40));

        jButton28.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton28.setForeground(new java.awt.Color(255, 255, 255));
        jButton28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/check_1.png"))); // NOI18N
        jButton28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton28ActionPerformed(evt);
            }
        });
        jPanel29.add(jButton28, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 49, 40));

        jButton29.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton29.setForeground(new java.awt.Color(255, 255, 255));
        jButton29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/refresh-button.png"))); // NOI18N
        jButton29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton29ActionPerformed(evt);
            }
        });
        jPanel29.add(jButton29, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, 49, 40));

        jPanel28.add(jPanel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(1360, 600, 230, 60));

        reservationtab5.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        reservationtab5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No.", "Room No.", "Bed Type", "Room Type", "Status"
            }
        ));
        reservationtab5.setRowHeight(30);
        reservationtab5.setShowVerticalLines(true);
        reservationtab5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                reservationtab5MouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(reservationtab5);

        jPanel28.add(jScrollPane8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 660, 1590, 390));

        reservationtab6.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        reservationtab6.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No.", "Room No.", "Bed Type", "Room Type", "Status"
            }
        ));
        reservationtab6.setRowHeight(30);
        reservationtab6.setShowVerticalLines(true);
        reservationtab6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                reservationtab6MouseClicked(evt);
            }
        });
        jScrollPane9.setViewportView(reservationtab6);

        jPanel28.add(jScrollPane9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 1590, 390));

        jPanel30.setBackground(new java.awt.Color(255, 255, 255));
        jPanel30.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/delete.png"))); // NOI18N
        jButton23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton23ActionPerformed(evt);
            }
        });
        jPanel30.add(jButton23, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, 50, 40));

        jButton25.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton25.setForeground(new java.awt.Color(255, 255, 255));
        jButton25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/check_1.png"))); // NOI18N
        jButton25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton25ActionPerformed(evt);
            }
        });
        jPanel30.add(jButton25, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 49, 40));

        jButton24.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton24.setForeground(new java.awt.Color(255, 255, 255));
        jButton24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/refresh-button.png"))); // NOI18N
        jButton24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton24ActionPerformed(evt);
            }
        });
        jPanel30.add(jButton24, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, 49, 40));

        jButton26.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton26.setForeground(new java.awt.Color(255, 255, 255));
        jButton26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/plus.png"))); // NOI18N
        jButton26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton26ActionPerformed(evt);
            }
        });
        jPanel30.add(jButton26, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 10, 49, 40));

        jPanel28.add(jPanel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(1340, 130, 260, 60));

        jLabel83.setFont(new java.awt.Font("Segoe UI", 3, 48)); // NOI18N
        jLabel83.setText("MANAGE ROOM");
        jPanel28.add(jLabel83, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, -1, -1));

        jLabel84.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/fffff.png"))); // NOI18N
        jPanel28.add(jLabel84, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 660, 1620, 1060));

        jLabel87.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/GL TRAVELODGE (1).png"))); // NOI18N
        jPanel28.add(jLabel87, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1620, -1));

        jLabel85.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/fffff.png"))); // NOI18N
        jPanel28.add(jLabel85, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1620, 860));

        jLabel86.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/fffff.png"))); // NOI18N
        jPanel28.add(jLabel86, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1620, 860));

        jTabbedPane1.addTab("tab6", jPanel28);

        jPanel32.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel95.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/GL TRAVELODGE (1).png"))); // NOI18N
        jPanel32.add(jLabel95, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1620, -1));

        jLabel100.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Untitled design (6).png"))); // NOI18N
        jLabel100.setText("jLabel100");
        jPanel32.add(jLabel100, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 220, 620, 350));

        jLabel101.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Untitled design (4).png"))); // NOI18N
        jLabel101.setText("jLabel100");
        jPanel32.add(jLabel101, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 580, 620, 350));

        jLabel102.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Untitled design (7).png"))); // NOI18N
        jLabel102.setText("jLabel100");
        jPanel32.add(jLabel102, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 220, 620, 350));

        jLabel97.setFont(new java.awt.Font("Segoe UI", 3, 48)); // NOI18N
        jLabel97.setText("ROOM DETAILS");
        jPanel32.add(jLabel97, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 160, -1, -1));

        jLabel96.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/fffff.png"))); // NOI18N
        jLabel96.setText("jLabel96");
        jPanel32.add(jLabel96, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 1610, 860));

        jTabbedPane1.addTab("tab7", jPanel32);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, -43, -1, 1130));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
          jTabbedPane1.setSelectedIndex(1);
        int booknum = 0;  
        int sum = 0;
        int cust = 0;
        int check = 0;
        int avail= 0;
        int dirty = 0;
        int checkout = 0;
        int totemp = 0;
       
         try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/checkoutdatabase","root","");
           String sql= "Select * from checkoutable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) reservationtab4.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5),
                   rs.getString(6),
                   rs.getString(7),
                   rs.getString(8),
                   rs.getString(9),
                   rs.getString(10),
                   rs.getString(11),
                   rs.getString(12),
                   rs.getString(13),
                   rs.getString(14),
                   rs.getString(15)});
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }
     //display total income   
    for(int i = 0; i<reservationtab4.getRowCount();i++)
    {
        sum = sum + Integer.parseInt(reservationtab4.getValueAt(i, 12).toString());       
    }
          jLabelroom9.setText(String.valueOf(sum));
      //display customer count    
    for(int i = 0; i<reservationtab2.getRowCount();i++)
    {
        cust = Integer.parseInt(reservationtab2.getValueAt(i, 0).toString());       
    }
          jLabelroom12.setText(String.valueOf(cust));
      //display total check-In  
    for(int i = 0; i<reservationtab2.getRowCount();i++)
    {
        check = Integer.parseInt(reservationtab2.getValueAt(i, 0).toString());       
    }
          jLabelroom8.setText(String.valueOf(check));   
    //display occupied room
     for(int i = 0; i<reservationtab2.getRowCount();i++)
    {
        avail = Integer.parseInt(reservationtab2.getValueAt(i, 0).toString());       
    }
          jLabelroom5.setText(String.valueOf(avail));       
      for(int i = 0; i<reservationtab3.getRowCount();i++)
    {
        booknum = Integer.parseInt(reservationtab3.getValueAt(i, 0).toString());       
    }
          jLabelroom7.setText(String.valueOf(booknum)); 
    
     //display dirty rooms
      for(int i = 0; i<reservationtab5.getRowCount();i++)
    {
        dirty = Integer.parseInt(reservationtab5.getValueAt(i, 0).toString());       
    }
          jLabelroom13.setText(String.valueOf(dirty));      
          
     //display total Check Out  
    for(int i = 0; i<reservationtab4.getRowCount();i++)
    {
        checkout = Integer.parseInt(reservationtab4.getValueAt(i, 0).toString());       
    }
          jLabelroom14.setText(String.valueOf(checkout)); 
       //display total employee
    for(int i = 0; i<jTableform.getRowCount();i++)
    {
        totemp = Integer.parseInt(jTableform.getValueAt(i, 0).toString());       
    }
          jLabelroom15.setText(String.valueOf(totemp));      
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
          jTabbedPane1.setSelectedIndex(0);
        int booknum = 0;  
        int sum = 0;
        int cust = 0;
        int check = 0;
        int avail=0;
        int dirty = 0;
        int checkout = 0;
        int totemp = 0;
        
        try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/reservationdatabase","root","");
           String sql= "Select * from reservationtable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) reservationtab2.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5),
                   rs.getString(6),
                   rs.getString(7),
                   rs.getString(8),
                   rs.getString(9),
                   rs.getString(10),
                   rs.getString(11),
                   rs.getString(12),
                   rs.getString(13),
                   rs.getString(14)});
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }
     //display total income   
    for(int i = 0; i<reservationtab4.getRowCount();i++)
    {
        sum = sum + Integer.parseInt(reservationtab4.getValueAt(i, 12).toString());       
    }
          jLabelroom9.setText(String.valueOf(sum));
      //display customer count    
    for(int i = 0; i<reservationtab2.getRowCount();i++)
    {
        cust = Integer.parseInt(reservationtab2.getValueAt(i, 0).toString());       
    }
          jLabelroom12.setText(String.valueOf(cust));
      //display total check-In  
    for(int i = 0; i<reservationtab2.getRowCount();i++)
    {
        check = Integer.parseInt(reservationtab2.getValueAt(i, 0).toString());       
    }
          jLabelroom8.setText(String.valueOf(check));   
    //display occupied room
     for(int i = 0; i<reservationtab2.getRowCount();i++)
    {
        avail = Integer.parseInt(reservationtab2.getValueAt(i, 0).toString());       
    }
          jLabelroom5.setText(String.valueOf(avail));       
      for(int i = 0; i<reservationtab3.getRowCount();i++)
    {
        booknum = Integer.parseInt(reservationtab3.getValueAt(i, 0).toString());       
    }
          jLabelroom7.setText(String.valueOf(booknum));  
          
      for(int i = 0; i<reservationtab5.getRowCount();i++)
    {
        dirty = Integer.parseInt(reservationtab5.getValueAt(i, 0).toString());       
    }
          jLabelroom13.setText(String.valueOf(dirty));      
          
      //display total Check Out  
    for(int i = 0; i<reservationtab4.getRowCount();i++)
    {
        checkout = Integer.parseInt(reservationtab4.getValueAt(i, 0).toString());       
    }
          jLabelroom14.setText(String.valueOf(checkout));     
    //display total employee
    for(int i = 0; i<jTableform.getRowCount();i++)
    {
        totemp = Integer.parseInt(jTableform.getValueAt(i, 0).toString());       
    }
          jLabelroom15.setText(String.valueOf(totemp));     
      
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
          jTabbedPane1.setSelectedIndex(2);
          
              try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/bookeddatabase","root","");
           String sql= "Select * from bookedtable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) reservationtab3.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5),
                   rs.getString(6),
                   rs.getString(7),
                   rs.getString(8),
                   rs.getString(9),
                   rs.getString(10),
                   rs.getString(11),
                   rs.getString(12),
                   rs.getString(13),
                   rs.getString(14)});
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }       
      
              
              int booknum = 0;  
        int sum = 0;
        int cust = 0;
        int check = 0;
        int avail = 0;
        int dirty = 0;
        int checkout = 0;
        int totemp = 0;
        
        try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/reservationdatabase","root","");
           String sql= "Select * from reservationtable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) reservationtab2.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5),
                   rs.getString(6),
                   rs.getString(7),
                   rs.getString(8),
                   rs.getString(9),
                   rs.getString(10),
                   rs.getString(11),
                   rs.getString(12),
                   rs.getString(13),
                   rs.getString(14)});
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }
     //display total income   
    for(int i = 0; i<reservationtab4.getRowCount();i++)
    {
        sum = sum + Integer.parseInt(reservationtab4.getValueAt(i, 12).toString());       
    }
          jLabelroom9.setText(String.valueOf(sum));
      //display customer count    
    for(int i = 0; i<reservationtab2.getRowCount();i++)
    {
        cust = Integer.parseInt(reservationtab2.getValueAt(i, 0).toString());       
    }
          jLabelroom12.setText(String.valueOf(cust));
      //display total check-In  
    for(int i = 0; i<reservationtab2.getRowCount();i++)
    {
        check = Integer.parseInt(reservationtab2.getValueAt(i, 0).toString());       
    }
          jLabelroom8.setText(String.valueOf(check));   
    //display occupied room
     for(int i = 0; i<reservationtab2.getRowCount();i++)
    {
        avail = Integer.parseInt(reservationtab2.getValueAt(i, 0).toString());       
    }
          jLabelroom5.setText(String.valueOf(avail));       
      for(int i = 0; i<reservationtab3.getRowCount();i++)
    {
        booknum = Integer.parseInt(reservationtab3.getValueAt(i, 0).toString());       
    }
          jLabelroom7.setText(String.valueOf(booknum)); 
     //display dirty rooms
      for(int i = 0; i<reservationtab5.getRowCount();i++)
    {
        dirty = Integer.parseInt(reservationtab5.getValueAt(i, 0).toString());       
    }
          jLabelroom13.setText(String.valueOf(dirty));   
          
     //display total Check Out  
    for(int i = 0; i<reservationtab4.getRowCount();i++)
    {
        checkout = Integer.parseInt(reservationtab4.getValueAt(i, 0).toString());       
    }
          jLabelroom14.setText(String.valueOf(checkout));
       //display total employee
    for(int i = 0; i<jTableform.getRowCount();i++)
    {
        totemp = Integer.parseInt(jTableform.getValueAt(i, 0).toString());       
    }
          jLabelroom15.setText(String.valueOf(totemp));
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        jTabbedPane1.setSelectedIndex(3);
        
        try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/reservationdatabase","root","");
           String sql= "Select * from reservationtable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) reservationtab2.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5),
                   rs.getString(6),
                   rs.getString(7),
                   rs.getString(8),
                   rs.getString(9),
                   rs.getString(10),
                   rs.getString(11),
                   rs.getString(12),
                   rs.getString(13),
                   rs.getString(14)});
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }   
    }//GEN-LAST:event_jButton6ActionPerformed

 
    
    private void ContPerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ContPerActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ContPerActionPerformed

    private void priceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_priceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_priceActionPerformed

    private void BTYPEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTYPEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BTYPEActionPerformed

    private void PaymentMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PaymentMActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PaymentMActionPerformed

    private void jdate2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jdate2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jdate2ActionPerformed

    private void RTYPEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RTYPEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RTYPEActionPerformed

    private void PaymetSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PaymetSActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PaymetSActionPerformed

    private void ResiAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResiAddActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ResiAddActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        jTabbedPane1.setSelectedIndex(4);
        
        int booknum = 0;  
        int sum = 0;
        int cust = 0;
        int check = 0;
        int avail=0;
        int totemp = 0;
        try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/reservationdatabase","root","");
           String sql= "Select * from reservationtable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) reservationtab2.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5),
                   rs.getString(6),
                   rs.getString(7),
                   rs.getString(8),
                   rs.getString(9),
                   rs.getString(10),
                   rs.getString(11),
                   rs.getString(12),
                   rs.getString(13),
                   rs.getString(14)});
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }
       
          
    try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/employeedatabase","root","");
           String sql= "Select * from employeetable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) jTableform.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5),
                   rs.getString(6),
                   rs.getString(7),
                   rs.getString(8),
                   rs.getString(9),
                   rs.getString(10),
                   rs.getString(11)});
                  
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }      
    
       //display total income   
    for(int i = 0; i<reservationtab4.getRowCount();i++)
    {
        sum = sum + Integer.parseInt(reservationtab4.getValueAt(i, 12).toString());       
    }
          jLabelroom9.setText(String.valueOf(sum));
      //display customer count    
    for(int i = 0; i<reservationtab2.getRowCount();i++)
    {
        cust = Integer.parseInt(reservationtab2.getValueAt(i, 0).toString());       
    }
          jLabelroom12.setText(String.valueOf(cust));
      //display total check-In  
    for(int i = 0; i<reservationtab2.getRowCount();i++)
    {
        check = Integer.parseInt(reservationtab2.getValueAt(i, 0).toString());       
    }
          jLabelroom8.setText(String.valueOf(check));   
    //display occupied room
     for(int i = 0; i<reservationtab2.getRowCount();i++)
    {
        avail = Integer.parseInt(reservationtab2.getValueAt(i, 0).toString());       
    }
          jLabelroom5.setText(String.valueOf(avail));       
      for(int i = 0; i<reservationtab3.getRowCount();i++)
    {
        booknum = Integer.parseInt(reservationtab3.getValueAt(i, 0).toString());       
    }
          jLabelroom7.setText(String.valueOf(booknum)); 
     //display total employee
    for(int i = 0; i<jTableform.getRowCount();i++)
    {
        totemp = Integer.parseInt(jTableform.getValueAt(i, 0).toString());       
    }
          jLabelroom15.setText(String.valueOf(totemp));  
    }//GEN-LAST:event_jButton9ActionPerformed

    private void Last_NameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Last_NameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Last_NameActionPerformed

    private void EmpPositionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmpPositionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EmpPositionActionPerformed

    private void EmpGenderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmpGenderActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EmpGenderActionPerformed
    
    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
               

          int row = jTableform.getSelectedRow();
      if(row!=-1)
      {
          String NOMER = jTableform.getValueAt(row, 0).toString();
          String sql = "DELETE FROM employeetable WHERE tablenum='"+NOMER+"'";
          
          String resetno="ALTER TABLE employeetable DROP tablenum";
          String consecutivenumber="ALTER TABLE employeetable ADD tablenum  INT NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST";
          
          try{
              cont.createStatement().execute(sql);
              cont.createStatement().execute(resetno);
              cont.createStatement().execute(consecutivenumber);
              Icon icon = new javax.swing.ImageIcon(getClass().getResource("/Images/checked.png"));
               JOptionPane.showMessageDialog(this, "Deleted Successfully","Hooray",JOptionPane.INFORMATION_MESSAGE,icon);
              
              
         
          }catch(Exception ex){
              
              JOptionPane.showMessageDialog(this, "ERROR");
          }
      }
      //After enter it will automatically loadup/refresh the table
        String sql= "Select * from employeetable";
       try{
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) jTableform.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5),
                   rs.getString(6),
                   rs.getString(7),
                   rs.getString(8),
                   rs.getString(9),
                   rs.getString(10),
                   rs.getString(11)});
                 
           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
       }
       
        
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
  try{
          
            Class.forName("com.mysql.cj.jdbc.Driver");
            cont= DriverManager.getConnection("jdbc:mysql://localhost:3306/employeedatabase","root","");
            int row = jTableform.getSelectedRow();
            String value = (jTableform.getModel().getValueAt(row, 0).toString());
            String sql = "UPDATE employeetable SET empid=?,fname=?,sname=?,email=?,gender=?,phonenum=?,datebirth=?,age=?,position=?,identificationpic=? where tablenum="+value;
            pst = cont.prepareStatement(sql);
            pst.setString(1, Employee_ID.getText());
            pst.setString(2, First_Name.getText());
            pst.setString(3, Last_Name.getText());
            pst.setString(4, empemail.getText());
            pst.setString(5, EmpGender.getSelectedItem().toString());
            pst.setString(6, Phone_No1.getText());
            SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
            String date = sdf.format(jDateChooser1.getDate());
            pst.setString(7, date);
            pst.setString(8, empage.getSelectedItem().toString());
            pst.setString(9, EmpPosition.getSelectedItem().toString());
            pst.setBytes(10, userimage);
            pst.executeUpdate();
            pst.close();
            DefaultTableModel model = (DefaultTableModel)jTableform.getModel();
            model.setRowCount(0);
        
          
          
           JOptionPane.showMessageDialog(null, "Updated Successfully");
          
             
      }catch (SQLException | HeadlessException ex){
         Logger.getLogger(DashboardPage.class.getName()).log(Level.SEVERE, null, ex);
      } catch (ClassNotFoundException ex) {  
            Logger.getLogger(DashboardPage.class.getName()).log(Level.SEVERE, null, ex);
        }  
        
     
              Employee_ID.setText("");
              First_Name.setText("");
              Last_Name.setText("");
              empemail.setText("");
              jDateChooser1.setDate(null);
              Phone_No1.setText("");
              EmpGender.setSelectedIndex(0);
              empage.setSelectedIndex(0);
              EmpPosition.setSelectedIndex(0);
              jladdphoto.setIcon(null);      
        
    }//GEN-LAST:event_jButton11ActionPerformed

    private void Add1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Add1ActionPerformed
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        
        
        String employeeidentification = Employee_ID.getText();
        String firstname = First_Name.getText(); 
        String lastname = Last_Name.getText();
        String email = empemail.getText();   
        String gender = EmpGender.getSelectedItem().toString();
        String phonenumber = Phone_No1.getText();
        String datebirth = sdf.format(jDateChooser1.getDate());
        String age = empage.getSelectedItem().toString();
        String position = EmpPosition.getSelectedItem().toString();

        if(employeeidentification.equals("")){
            JOptionPane.showMessageDialog(null, "Employee ID No. Field is Empty");
        }else if (firstname.equals("")){
            JOptionPane.showMessageDialog(null, "First Name Field is Empty");
        }else if (lastname.equals("")){
            JOptionPane.showMessageDialog(null, "Last Name Field is Empty");
        }else if (email.equals("")){
            JOptionPane.showMessageDialog(null, "Email Field is Empty"); 
        }else if (phonenumber.equals("")){
            JOptionPane.showMessageDialog(null, "Phone No Field is Empty");
        }else if (datebirth.equals("")){
            JOptionPane.showMessageDialog(null, "Date of Birth Field is Empty");    
        }else{ 
            
        }
        try{
             File image = new File(path);
            FileInputStream fis = new FileInputStream(image);
            Class.forName("com.mysql.cj.jdbc.Driver");
            cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/employeedatabase","root","");
            pst = cont.prepareStatement("insert into employeetable(empid,fname,sname,email,gender,phonenum,datebirth,age,position,identificationpic) values (?,?,?,?,?,?,?,?,?,?)");
            pst.setString(1, employeeidentification);
            pst.setString(2, firstname);
            pst.setString(3, lastname);
            pst.setString(4, email);
            pst.setString(5, gender);
            pst.setString(6, phonenumber);
            pst.setString(7, datebirth);
            pst.setString(8, age);
            pst.setString(9, position);
            pst.setBytes(10, userimage);
            pst.executeUpdate();
            Icon icon = new javax.swing.ImageIcon(getClass().getResource("/Images/checked.png"));
            JOptionPane.showMessageDialog(this, "   Table is already added","Hooray!",JOptionPane.INFORMATION_MESSAGE,icon);

           
            Employee_ID.setText("");
              First_Name.setText("");
              Last_Name.setText("");
              empemail.setText("");
              jDateChooser1.setDate(null );
              Phone_No1.setText("");
              EmpGender.setSelectedIndex(0);
              empage.setSelectedIndex(0);
              EmpPosition.setSelectedIndex(0);
              jladdphoto.setIcon(null);
           
          
            
                                                                                          
         } catch (ClassNotFoundException ex){
           Logger.getLogger(DashboardPage.class.getName()).log(Level.SEVERE, null, ex);

        } catch (FileNotFoundException ex) {
            Logger.getLogger(DashboardPage.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(DashboardPage.class.getName()).log(Level.SEVERE, null, ex);
        }      
        
         try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/employeedatabase","root","");
           String sql= "Select * from employeetable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) jTableform.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5),
                   rs.getString(6),
                   rs.getString(7),
                   rs.getString(8),
                   rs.getString(9),
                   rs.getString(10),
                   rs.getString(11)});
                  
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }
                

    }//GEN-LAST:event_Add1ActionPerformed

    private void searcfieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searcfieldKeyReleased
           DefaultTableModel ob = (DefaultTableModel)jTableform.getModel();
            TableRowSorter<DefaultTableModel>obj=new TableRowSorter<>(ob);
            jTableform.setRowSorter(obj);
            obj.setRowFilter(RowFilter.regexFilter(searcfield.getText()));         
    }//GEN-LAST:event_searcfieldKeyReleased

    private void jTableformMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableformMouseClicked
           
        
        
              Employee_ID.setText(String.valueOf(jTableform.getValueAt(jTableform.getSelectedRow(),1)));
              First_Name.setText(String.valueOf(jTableform.getValueAt(jTableform.getSelectedRow(),2)));
              Last_Name.setText(String.valueOf(jTableform.getValueAt(jTableform.getSelectedRow(),3)));
              empemail.setText(String.valueOf(jTableform.getValueAt(jTableform.getSelectedRow(),4)));
              EmpGender.setSelectedItem(String.valueOf(jTableform.getValueAt(jTableform.getSelectedRow(),5)));
              Phone_No1.setText(String.valueOf(jTableform.getValueAt(jTableform.getSelectedRow(),6)));             
              empage.setSelectedItem(String.valueOf(jTableform.getValueAt(jTableform.getSelectedRow(),8)));
              EmpPosition.setSelectedItem(String.valueOf(jTableform.getValueAt(jTableform.getSelectedRow(),9)));
              
              
        int r = jTableform.getSelectedRow();
        String click = (jTableform.getModel().getValueAt(r, 0).toString());
        String sql = "SELECT * FROM employeetable WHERE tablenum='"+click+"'";
        try{
         DefaultTableModel tblmodel = (DefaultTableModel)jTableform.getModel();
         int index = jTableform.getSelectedRow();
         Date date = new SimpleDateFormat ("MM-dd-yyyy").parse((String)tblmodel.getValueAt(index, 7));
         jDateChooser1.setDate(date);
            
            pst = cont.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){      
        Blob image = (Blob) rs.getBlob(11);
        String path = "C:\\Users\\Administrator\\Pictures\\img2.jpg";
        byte [] buff = image.getBytes(1, (int)image.length());
        FileOutputStream fis = new FileOutputStream(path);
        fis.write(buff);
        ImageIcon icon = new ImageIcon(buff);
        jladdphoto.setIcon(icon);
        
                
            }
        }catch(Exception ex){
            
        }

                      
    }//GEN-LAST:event_jTableformMouseClicked

    private void Phone_No1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Phone_No1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Phone_No1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
              Employee_ID.setText("");
              First_Name.setText("");
              Last_Name.setText("");
              empemail.setText("");
              jDateChooser1.setDate(null);
              Phone_No1.setText("");
              EmpGender.setSelectedIndex(0);
              empage.setSelectedIndex(0);
              EmpPosition.setSelectedIndex(0);
              jladdphoto.setIcon(null);
              
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton11MouseClicked
         
        
    }//GEN-LAST:event_jButton11MouseClicked

    private void Employee_IDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Employee_IDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Employee_IDActionPerformed

    private void CPNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CPNActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CPNActionPerformed

    private void EmailaddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmailaddActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EmailaddActionPerformed

    private void jPanel5AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jPanel5AncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel5AncestorAdded

    private void RNOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RNOActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RNOActionPerformed

    private void searcfieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searcfieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searcfieldActionPerformed

    private void jDateChooser1123AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jDateChooser1123AncestorAdded
     
      
    }//GEN-LAST:event_jDateChooser1123AncestorAdded

    private void AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddActionPerformed
        JFileChooser chooser = new JFileChooser();
        chooser.showOpenDialog(null);
        File f = chooser.getSelectedFile();

        path = f.getAbsolutePath();
        BufferedImage img;
        try{
            img = ImageIO.read(chooser.getSelectedFile());

            ImageIcon imageic = new ImageIcon(new ImageIcon(img).getImage().getScaledInstance(220, 210, Image.SCALE_DEFAULT));
            jladdphoto.setIcon(imageic);

            File image = new File(path);
            FileInputStream fis = new FileInputStream(image);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buff = new byte [1024];

            for(int readNum; (readNum=fis.read(buff)) !=-1;)
            {
                bos.write(buff,0,readNum);
            }
            userimage = bos.toByteArray();
        }catch (IOException ex){
            Logger.getLogger(DashboardPage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_AddActionPerformed

    private void jtime3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtime3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtime3ActionPerformed

    private void jTextField1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField1KeyReleased
            DefaultTableModel ob = (DefaultTableModel)reservationtab2.getModel();
            TableRowSorter<DefaultTableModel>obj=new TableRowSorter<>(ob);
            reservationtab2.setRowSorter(obj);
            obj.setRowFilter(RowFilter.regexFilter(jTextField1.getText()));
    }//GEN-LAST:event_jTextField1KeyReleased

    private void reservationtab2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reservationtab2MouseClicked
              RNO.setSelectedItem(String.valueOf(reservationtab2.getValueAt(reservationtab2.getSelectedRow(),1)));
              BTYPE.setSelectedItem(String.valueOf(reservationtab2.getValueAt(reservationtab2.getSelectedRow(),2)));
              RTYPE.setSelectedItem(String.valueOf(reservationtab2.getValueAt(reservationtab2.getSelectedRow(),3)));
              price.setText(String.valueOf(reservationtab2.getValueAt(reservationtab2.getSelectedRow(),11)));
              PaymetS.setSelectedItem(String.valueOf(reservationtab2.getValueAt(reservationtab2.getSelectedRow(),12)));
              PaymentM.setSelectedItem(String.valueOf(reservationtab2.getValueAt(reservationtab2.getSelectedRow(),13)));
              CPN.setText(String.valueOf(reservationtab2.getValueAt(reservationtab2.getSelectedRow(),6))); 
              ContPer.setText(String.valueOf(reservationtab2.getValueAt(reservationtab2.getSelectedRow(),7)));                          
              Emailadd.setText(String.valueOf(reservationtab2.getValueAt(reservationtab2.getSelectedRow(),8)));
              ResiAdd.setText(String.valueOf(reservationtab2.getValueAt(reservationtab2.getSelectedRow(),9)));
              Gend.setSelectedItem(String.valueOf(reservationtab2.getValueAt(reservationtab2.getSelectedRow(),10)));
              
              
        int index = reservationtab2.getSelectedRow();
        
        TableModel tblmodel = reservationtab2.getModel();
        
        String roomnum1 = tblmodel.getValueAt(index, 1).toString();
        String bedtype1 = tblmodel.getValueAt(index, 2).toString();
        String roomtype1 = tblmodel.getValueAt(index, 3).toString();   
        String checkindate1 =  tblmodel.getValueAt(index, 4).toString();;       
        String checkintime1 =  tblmodel.getValueAt(index, 5).toString();             
        String price21 =  tblmodel.getValueAt(index, 11).toString();       
        String paymentstats1 =  tblmodel.getValueAt(index, 12).toString();       
        String paymentmethod1 =  tblmodel.getValueAt(index, 13).toString();       
        String contperson1 =  tblmodel.getValueAt(index, 6).toString();       
        String contnumber1 =  tblmodel.getValueAt(index, 7).toString();       
        String emailaddress1 =  tblmodel.getValueAt(index, 8).toString();       
        String resdaress1 =  tblmodel.getValueAt(index, 9).toString();       
        String gender31 =  tblmodel.getValueAt(index, 10).toString();
        
        jtRowData1.setVisible(true);
        jtRowData1.pack();
        jtRowData1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        jtRowData1.roonum.setText(roomnum1);
        jtRowData1.bedt.setText(bedtype1);
        jtRowData1.roomt.setText(roomtype1);
        jtRowData1.checknd.setText(checkindate1);
        jtRowData1.checknt.setText(checkintime1);
        jtRowData1.prices.setText(price21);
        jtRowData1.paystats.setText(paymentstats1);
        jtRowData1.paymeth.setText(paymentmethod1);
        jtRowData1.contpers.setText(contperson1);
        jtRowData1.contnumb.setText(contnumber1);
        jtRowData1.emailaddd.setText(emailaddress1);
        jtRowData1.residaddd.setText(resdaress1);
        jtRowData1.aids.setText(gender31);
              

    }//GEN-LAST:event_reservationtab2MouseClicked

    private void ContPer1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ContPer1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ContPer1ActionPerformed

    private void price1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_price1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_price1ActionPerformed

    private void BTYPE1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTYPE1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BTYPE1ActionPerformed

    private void PaymentM1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PaymentM1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PaymentM1ActionPerformed

    private void RNO1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RNO1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RNO1ActionPerformed

    private void jdate3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jdate3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jdate3ActionPerformed

    private void RTYPE1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RTYPE1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RTYPE1ActionPerformed

    private void PaymetS1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PaymetS1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PaymetS1ActionPerformed

    private void jbsave1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbsave1ActionPerformed
      int row = reservationtab3.getSelectedRow();
      if(row!=-1)
      {
          String NOMER = reservationtab3.getValueAt(row, 0).toString();
          String sql = "DELETE FROM bookedtable WHERE tablenum='"+NOMER+"'";
          
          String resetno="ALTER TABLE bookedtable DROP tablenum";
          String consecutivenumber="ALTER TABLE bookedtable ADD tablenum  INT NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST";
          
          try{
              cont.createStatement().execute(sql);
              cont.createStatement().execute(resetno);
              cont.createStatement().execute(consecutivenumber);
              Icon icon = new javax.swing.ImageIcon(getClass().getResource("/Images/checked.png"));
               JOptionPane.showMessageDialog(this, "Booked Cancel Successfully","Hooray",JOptionPane.INFORMATION_MESSAGE,icon);
              
              
         
          }catch(Exception ex){
              
              JOptionPane.showMessageDialog(this, "ERROR");
          }
      }
      try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/bookeddatabase","root","");
           String sql= "Select * from bookedtable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) reservationtab3.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5),
                   rs.getString(6),
                   rs.getString(7),
                   rs.getString(8),
                   rs.getString(9),
                   rs.getString(10),
                   rs.getString(11),
                   rs.getString(12),
                   rs.getString(13),
                   rs.getString(14)});
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }     
      
    RNO1.setSelectedIndex(0);
    BTYPE1.setSelectedIndex(0);
    RTYPE1.setSelectedIndex(0);
    PaymetS1.setSelectedIndex(0);
    PaymentM1.setSelectedIndex(0);
    Gend1.setSelectedIndex(0);
    price1.setText("");
    CPN1.setText("");
    ContPer1.setText("");
    Emailadd1.setText("");
    ResiAdd1.setText("");
    }//GEN-LAST:event_jbsave1ActionPerformed

    private void ResiAdd1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResiAdd1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ResiAdd1ActionPerformed

    private void CPN1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CPN1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CPN1ActionPerformed

    private void Emailadd1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Emailadd1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Emailadd1ActionPerformed

    private void jtime4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtime4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtime4ActionPerformed

    private void reservationtab3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reservationtab3MouseClicked
              RNO1.setSelectedItem(String.valueOf(reservationtab3.getValueAt(reservationtab3.getSelectedRow(),1)));
              BTYPE1.setSelectedItem(String.valueOf(reservationtab3.getValueAt(reservationtab3.getSelectedRow(),2)));
              RTYPE1.setSelectedItem(String.valueOf(reservationtab3.getValueAt(reservationtab3.getSelectedRow(),3)));
              price1.setText(String.valueOf(reservationtab3.getValueAt(reservationtab3.getSelectedRow(),11)));
              PaymetS1.setSelectedItem(String.valueOf(reservationtab3.getValueAt(reservationtab3.getSelectedRow(),12)));
              PaymentM1.setSelectedItem(String.valueOf(reservationtab3.getValueAt(reservationtab3.getSelectedRow(),13)));
              CPN1.setText(String.valueOf(reservationtab3.getValueAt(reservationtab3.getSelectedRow(),6))); 
              ContPer1.setText(String.valueOf(reservationtab3.getValueAt(reservationtab3.getSelectedRow(),7)));                          
              Emailadd1.setText(String.valueOf(reservationtab3.getValueAt(reservationtab3.getSelectedRow(),8)));
              ResiAdd1.setText(String.valueOf(reservationtab3.getValueAt(reservationtab3.getSelectedRow(),9)));
              Gend1.setSelectedItem(String.valueOf(reservationtab3.getValueAt(reservationtab3.getSelectedRow(),10)));
              
              int index = reservationtab3.getSelectedRow();
        
        TableModel tblmodel = reservationtab3.getModel();
        
        String roomnum1 = tblmodel.getValueAt(index, 1).toString();
        String bedtype1 = tblmodel.getValueAt(index, 2).toString();
        String roomtype1 = tblmodel.getValueAt(index, 3).toString();   
        String checkindate1 =  tblmodel.getValueAt(index, 4).toString();;       
        String checkintime1 =  tblmodel.getValueAt(index, 5).toString();             
        String price21 =  tblmodel.getValueAt(index, 11).toString();       
        String paymentstats1 =  tblmodel.getValueAt(index, 12).toString();       
        String paymentmethod1 =  tblmodel.getValueAt(index, 13).toString();       
        String contperson1 =  tblmodel.getValueAt(index, 6).toString();       
        String contnumber1 =  tblmodel.getValueAt(index, 7).toString();       
        String emailaddress1 =  tblmodel.getValueAt(index, 8).toString();       
        String resdaress1 =  tblmodel.getValueAt(index, 9).toString();       
        String gender31 =  tblmodel.getValueAt(index, 10).toString();
        
        jtRowData.setVisible(true);
        jtRowData.pack();
        jtRowData.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        jtRowData.roonum.setText(roomnum1);
        jtRowData.bedt.setText(bedtype1);
        jtRowData.roomt.setText(roomtype1);
        jtRowData.checknd.setText(checkindate1);
        jtRowData.checknt.setText(checkintime1);
        jtRowData.prices.setText(price21);
        jtRowData.paystats.setText(paymentstats1);
        jtRowData.paymeth.setText(paymentmethod1);
        jtRowData.contpers.setText(contperson1);
        jtRowData.contnumb.setText(contnumber1);
        jtRowData.emailaddd.setText(emailaddress1);
        jtRowData.residaddd.setText(resdaress1);
        jtRowData.aids.setText(gender31);
    }//GEN-LAST:event_reservationtab3MouseClicked

    private void jTextField2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField2KeyReleased
          DefaultTableModel ob = (DefaultTableModel)reservationtab3.getModel();
            TableRowSorter<DefaultTableModel>obj=new TableRowSorter<>(ob);
            reservationtab3.setRowSorter(obj);
            obj.setRowFilter(RowFilter.regexFilter(jTextField2.getText()));      

        
    }//GEN-LAST:event_jTextField2KeyReleased

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
      
      int row = reservationtab3.getSelectedRow();
      if(row!=-1)
      {
          String NOMER = reservationtab3.getValueAt(row, 0).toString();
          String sql = "DELETE FROM bookedtable WHERE tablenum='"+NOMER+"'";
          
          String resetno="ALTER TABLE bookedtable DROP tablenum";
          String consecutivenumber="ALTER TABLE bookedtable ADD tablenum  INT NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST";
          
          try{
              cont.createStatement().execute(sql);
              cont.createStatement().execute(resetno);
              cont.createStatement().execute(consecutivenumber);
              JOptionPane.showMessageDialog(this, "Deleted Successfully");
              
         
          }catch(Exception ex){
              JOptionPane.showMessageDialog(this, "ERROR");
          }
      }
      try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/bookeddatabase","root","");
           String sql= "Select * from bookedtable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) reservationtab3.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5),
                   rs.getString(6),
                   rs.getString(7),
                   rs.getString(8),
                   rs.getString(9),
                   rs.getString(10),
                   rs.getString(11),
                   rs.getString(12),
                   rs.getString(13),
                   rs.getString(14)});
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }     
      
    RNO1.setSelectedIndex(0);
    BTYPE1.setSelectedIndex(0);
    RTYPE1.setSelectedIndex(0);
    PaymetS1.setSelectedIndex(0);
    PaymentM1.setSelectedIndex(0);
    Gend1.setSelectedIndex(0);
    price1.setText("");
    CPN1.setText("");
    ContPer1.setText("");
    Emailadd1.setText("");
    ResiAdd1.setText("");
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jPanel14AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jPanel14AncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel14AncestorAdded

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
      try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/bookeddatabase","root","");
           String sql= "Select * from bookedtable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) reservationtab3.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5),
                   rs.getString(6),
                   rs.getString(7),
                   rs.getString(8),
                   rs.getString(9),
                   rs.getString(10),
                   rs.getString(11),
                   rs.getString(12),
                   rs.getString(13),
                   rs.getString(14)});
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }     
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
     int row = reservationtab2.getSelectedRow();
      if(row!=-1)
      {
          String NOMER = reservationtab2.getValueAt(row, 0).toString();
          String sql = "DELETE FROM reservationtable WHERE numbertable='"+NOMER+"'";
          
          String resetno="ALTER TABLE reservationtable DROP numbertable";
          String consecutivenumber="ALTER TABLE reservationtable ADD numbertable  INT NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST";
          
          try{
              cont.createStatement().execute(sql);
              cont.createStatement().execute(resetno);
              cont.createStatement().execute(consecutivenumber);
              JOptionPane.showMessageDialog(this, "Deleted Succesfully");
              
         
          }catch(Exception ex){
              JOptionPane.showMessageDialog(this, "ERROR");
          }
      }
      
         try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/reservationdatabase","root","");
           String sql= "Select * from reservationtable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) reservationtab2.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5),
                   rs.getString(6),
                   rs.getString(7),
                   rs.getString(8),
                   rs.getString(9),
                   rs.getString(10),
                   rs.getString(11),
                   rs.getString(12),
                   rs.getString(13),
                   rs.getString(14)});
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }
    RNO.setSelectedIndex(0);
    BTYPE.setSelectedIndex(0);
    RTYPE.setSelectedIndex(0);
    PaymetS.setSelectedIndex(0);
    PaymentM.setSelectedIndex(0);
    Gend.setSelectedIndex(0);
    price.setText("");
    CPN.setText("");
    ContPer.setText("");
    Emailadd.setText("");
    ResiAdd.setText("");
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
      try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/reservationdatabase","root","");
           String sql= "Select * from reservationtable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) reservationtab2.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5),
                   rs.getString(6),
                   rs.getString(7),
                   rs.getString(8),
                   rs.getString(9),
                   rs.getString(10),
                   rs.getString(11),
                   rs.getString(12),
                   rs.getString(13),
                   rs.getString(14)});
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
    RNO1.setSelectedIndex(0);
    BTYPE1.setSelectedIndex(0);
    RTYPE1.setSelectedIndex(0);
    PaymetS1.setSelectedIndex(0);
    PaymentM1.setSelectedIndex(0);
    Gend1.setSelectedIndex(0);
    price1.setText("");
    CPN1.setText("");
    ContPer1.setText("");
    Emailadd1.setText("");
    ResiAdd1.setText("");
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton19ActionPerformed

    private void reservationtab4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reservationtab4MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_reservationtab4MouseClicked

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
       int row = reservationtab4.getSelectedRow();
      if(row!=-1)
      {
          String NOMER = reservationtab4.getValueAt(row, 0).toString();
          String sql = "DELETE FROM checkoutable WHERE tablenum='"+NOMER+"'";
          
          String resetno="ALTER TABLE checkoutable DROP tablenum";
          String consecutivenumber="ALTER TABLE checkoutable ADD tablenum  INT NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST";
          
          try{
              cont.createStatement().execute(sql);
              cont.createStatement().execute(resetno);
              cont.createStatement().execute(consecutivenumber);
              JOptionPane.showMessageDialog(this, "Deleted Successfully");
              
         
          }catch(Exception ex){
              JOptionPane.showMessageDialog(this, "ERROR");
          }
      }
      
       try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/checkoutdatabase","root","");
           String sql= "Select * from checkoutable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) reservationtab4.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5),
                   rs.getString(6),
                   rs.getString(7),
                   rs.getString(8),
                   rs.getString(9),
                   rs.getString(10),
                   rs.getString(11),
                   rs.getString(12),
                   rs.getString(13),
                   rs.getString(14)});
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }
    }//GEN-LAST:event_jButton20ActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
    try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/checkoutdatabase","root","");
           String sql= "Select * from checkoutable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) reservationtab4.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5),
                   rs.getString(6),
                   rs.getString(7),
                   rs.getString(8),
                   rs.getString(9),
                   rs.getString(10),
                   rs.getString(11),
                   rs.getString(12),
                   rs.getString(13),
                   rs.getString(14),
                   rs.getString(15)});
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }
    }//GEN-LAST:event_jButton21ActionPerformed

    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton22ActionPerformed

    private void jButton24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton24ActionPerformed
   try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/manageroomdatabase","root","");
           String sql= "Select * from manageroomtable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) reservationtab5.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5)});
                   
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }
   
     try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/availableroomdatabase","root","");
           String sql= "Select * from availtable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) reservationtab6.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5)});
                          
                 
                   
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }
    }//GEN-LAST:event_jButton24ActionPerformed

    private void jButton25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton25ActionPerformed
         int row = reservationtab6.getSelectedRow();
      if(row!=-1)
      {
          String NOMER = reservationtab6.getValueAt(row, 0).toString();
          String sql = "DELETE FROM availtable WHERE tablenumber='"+NOMER+"'";
          
          String resetno="ALTER TABLE availtable DROP tablenumber";
          String consecutivenumber="ALTER TABLE availtable ADD tablenumber  INT NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST";
          
          try{
              cont.createStatement().execute(sql);
              cont.createStatement().execute(resetno);
              cont.createStatement().execute(consecutivenumber);
             
              
              
          }catch(Exception ex){
              JOptionPane.showMessageDialog(this, "ERROR");
          }
      }
      
      try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/availableroomdatabase","root","");
           String sql= "Select * from availtable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) reservationtab6.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5)});
                   
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }
    }//GEN-LAST:event_jButton25ActionPerformed

    private void reservationtab5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reservationtab5MouseClicked
        int index = reservationtab5.getSelectedRow();
        
        TableModel tblmodel = reservationtab5.getModel();
        
        String roomnum2 = tblmodel.getValueAt(index, 1).toString();
        String bedtype2 = tblmodel.getValueAt(index, 2).toString();
        String roomtype2 = tblmodel.getValueAt(index,3).toString();   
        
        
        jtRowData2.setVisible(true);
        jtRowData2.pack();
        jtRowData2.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        jtRowData2.roomnum2.setText(roomnum2);
        jtRowData2.bedt2.setText(bedtype2);
        jtRowData2.roomt2.setText(roomtype2);
        


      
    }//GEN-LAST:event_reservationtab5MouseClicked

    private void jButton26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton26ActionPerformed
      
     addroompage adrp = new addroompage();
     adrp.setVisible(true);
    
    }//GEN-LAST:event_jButton26ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
     jTabbedPane1.setSelectedIndex(5);
     
     int booknum = 0;  
        int sum = 0;
        int cust = 0;
        int check = 0;
        int avail=0;
        int dirty = 0;
        int checkout = 0;
        int totemp = 0;
        
        
         
          //display total income   
    for(int i = 0; i<reservationtab4.getRowCount();i++)
    {
        sum = sum + Integer.parseInt(reservationtab4.getValueAt(i, 12).toString());       
    }
          jLabelroom9.setText(String.valueOf(sum));
      //display customer count    
    for(int i = 0; i<reservationtab2.getRowCount();i++)
    {
        cust = Integer.parseInt(reservationtab2.getValueAt(i, 0).toString());       
    }
          jLabelroom12.setText(String.valueOf(cust));
      //display total check-In  
    for(int i = 0; i<reservationtab2.getRowCount();i++)
    {
        check = Integer.parseInt(reservationtab2.getValueAt(i, 0).toString());       
    }
          jLabelroom8.setText(String.valueOf(check));   
    //display occupied room
     for(int i = 0; i<reservationtab2.getRowCount();i++)
    {
        avail = Integer.parseInt(reservationtab2.getValueAt(i, 0).toString());       
    }
          jLabelroom5.setText(String.valueOf(avail));       
      for(int i = 0; i<reservationtab3.getRowCount();i++)
    {
        booknum = Integer.parseInt(reservationtab3.getValueAt(i, 0).toString());       
    }
          jLabelroom7.setText(String.valueOf(booknum)); 
          
    //display dirty rooms
      for(int i = 0; i<reservationtab5.getRowCount();i++)
    {
        dirty = Integer.parseInt(reservationtab5.getValueAt(i, 0).toString());       
    }
          jLabelroom13.setText(String.valueOf(dirty));
     //display total Check Out  
    for(int i = 0; i<reservationtab4.getRowCount();i++)
    {
        checkout = Integer.parseInt(reservationtab4.getValueAt(i, 0).toString());       
    }
          jLabelroom14.setText(String.valueOf(checkout)); 
     //display total employee
    for(int i = 0; i<jTableform.getRowCount();i++)
    {
        totemp = Integer.parseInt(jTableform.getValueAt(i, 0).toString());       
    }
          jLabelroom15.setText(String.valueOf(totemp));       
          
          
           try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/manageroomdatabase","root","");
           String sql= "Select * from manageroomtable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) reservationtab5.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5)});
                   
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }
           
            try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/availableroomdatabase","root","");
           String sql= "Select * from availtable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) reservationtab6.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5)});
                          
                 
                   
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }
           
           
    }//GEN-LAST:event_jButton12ActionPerformed

    private void price1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_price1KeyPressed
       char c = evt.getKeyChar();
       if(Character.isLetter(c)){
           price1.setEditable(false);
           
           JOptionPane.showMessageDialog(this, "You must Enter Number Only");
           price1.setText("");
       }else{
           price1.setEditable(true);
       }
    }//GEN-LAST:event_price1KeyPressed

    private void priceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_priceKeyPressed
       char c = evt.getKeyChar();
       if(Character.isLetter(c)){
           price.setEditable(false);
           
           JOptionPane.showMessageDialog(this, "You must Enter Number Only");
           price.setText("");
       }else{
           price.setEditable(true);
       }
    }//GEN-LAST:event_priceKeyPressed

    private void RNOKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RNOKeyPressed
     
    }//GEN-LAST:event_RNOKeyPressed

    private void RNOKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RNOKeyReleased
      
     
    }//GEN-LAST:event_RNOKeyReleased

    private void reservationtab6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reservationtab6MouseClicked
       int index = reservationtab6.getSelectedRow();
        
        TableModel tblmodel = reservationtab6.getModel();
        
        String roomnum2 = tblmodel.getValueAt(index, 1).toString();
           
        
        
        jtRowData3.setVisible(true);
        jtRowData3.pack();
        jtRowData3.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        jtRowData3.roomnum3.setText(roomnum2);
        
    }//GEN-LAST:event_reservationtab6MouseClicked

    private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton23ActionPerformed
       int row = reservationtab6.getSelectedRow();
      if(row!=-1)
      {
          String NOMER = reservationtab6.getValueAt(row, 0).toString();
          String sql = "DELETE FROM availtable WHERE tablenumber='"+NOMER+"'";
          
          String resetno="ALTER TABLE availtable DROP tablenumber";
          String consecutivenumber="ALTER TABLE availtable ADD tablenumber  INT NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST";
          
          try{
              cont.createStatement().execute(sql);
              cont.createStatement().execute(resetno);
              cont.createStatement().execute(consecutivenumber);
             
              
         
          }catch(Exception ex){
              JOptionPane.showMessageDialog(this, "ERROR");
          }
      }
        try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/availableroomdatabase","root","");
           String sql= "Select * from availtable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) reservationtab6.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5)});
                          
                 
                   
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }
      
      
    }//GEN-LAST:event_jButton23ActionPerformed

    private void jButton27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton27ActionPerformed
       int row = reservationtab5.getSelectedRow();
      if(row!=-1)
      {
          String NOMER = reservationtab5.getValueAt(row, 0).toString();
          String sql = "DELETE FROM manageroomtable WHERE tablenumber='"+NOMER+"'";
          
          String resetno="ALTER TABLE manageroomtable DROP tablenumber";
          String consecutivenumber="ALTER TABLE manageroomtable ADD tablenumber  INT NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST";
          
          try{
              cont.createStatement().execute(sql);
              cont.createStatement().execute(resetno);
              cont.createStatement().execute(consecutivenumber);
             
              
         
          }catch(Exception ex){
              JOptionPane.showMessageDialog(this, "ERROR");
          }
      }
        try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/manageroomdatabase","root","");
           String sql= "Select * from manageroomtable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) reservationtab5.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5)});
                          
                 
                   
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }
      
    }//GEN-LAST:event_jButton27ActionPerformed

    private void jButton28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton28ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton28ActionPerformed

    private void jButton29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton29ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton29ActionPerformed

    private void jButton30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton30ActionPerformed
       try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           cont=DriverManager.getConnection("jdbc:mysql://localhost:3306/employeedatabase","root","");
           String sql= "Select * from employeetable";
           PreparedStatement pst = cont.prepareStatement(sql);
           ResultSet rs = pst.executeQuery();
           DefaultTableModel tblm =(DefaultTableModel) jTableform.getModel();
           tblm.setRowCount(0);
           while(rs.next()){
               tblm.addRow(new String []{
                   rs.getString(1),
                   rs.getString(2),
                   rs.getString(3),
                   rs.getString(4),
                   rs.getString(5),
                   rs.getString(6),
                   rs.getString(7),
                   rs.getString(8),
                   rs.getString(9),
                   rs.getString(10),
                   rs.getString(11)});
                  
                   

           }
       }catch (Exception ex){
           System.out.println("Error:"+ex.getMessage());
              
         }
    }//GEN-LAST:event_jButton30ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
      int out = JOptionPane.showConfirmDialog(null, "Do you really want to Logout?","Select",JOptionPane.YES_NO_OPTION);
     if(out==0){
     LoginPage lp = new LoginPage();
     lp.setVisible(true);
     }else{
         System.exit(0);
     }
     dispose();
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jTextField2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField2KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2KeyPressed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
       jTabbedPane1.setSelectedIndex(6);
    }//GEN-LAST:event_jButton5ActionPerformed

    /** 
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DashboardPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DashboardPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DashboardPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DashboardPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DashboardPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add;
    private javax.swing.JButton Add1;
    private javax.swing.JComboBox<String> BTYPE;
    private javax.swing.JComboBox<String> BTYPE1;
    private javax.swing.JTextField CPN;
    private javax.swing.JTextField CPN1;
    private javax.swing.JTextField ContPer;
    private javax.swing.JTextField ContPer1;
    private javax.swing.JTextField Emailadd;
    private javax.swing.JTextField Emailadd1;
    private javax.swing.JComboBox<String> EmpGender;
    private javax.swing.JComboBox<String> EmpPosition;
    private javax.swing.JTextField Employee_ID;
    private javax.swing.JTextField First_Name;
    private javax.swing.JComboBox<String> Gend;
    private javax.swing.JComboBox<String> Gend1;
    private javax.swing.JTextField Last_Name;
    private javax.swing.JComboBox<String> PaymentM;
    private javax.swing.JComboBox<String> PaymentM1;
    private javax.swing.JComboBox<String> PaymetS;
    private javax.swing.JComboBox<String> PaymetS1;
    private javax.swing.JTextField Phone_No1;
    private javax.swing.JComboBox<String> RNO;
    private javax.swing.JComboBox<String> RNO1;
    private javax.swing.JComboBox<String> RTYPE;
    private javax.swing.JComboBox<String> RTYPE1;
    private javax.swing.JTextField ResiAdd;
    private javax.swing.JTextField ResiAdd1;
    private javax.swing.JComboBox<String> empage;
    private javax.swing.JTextField empemail;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton27;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton29;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton30;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    public static javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabelroom12;
    private javax.swing.JLabel jLabelroom13;
    private javax.swing.JLabel jLabelroom14;
    private javax.swing.JLabel jLabelroom15;
    private javax.swing.JLabel jLabelroom5;
    private javax.swing.JLabel jLabelroom6;
    private javax.swing.JLabel jLabelroom7;
    private javax.swing.JLabel jLabelroom8;
    private javax.swing.JLabel jLabelroom9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTableform;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JButton jbsave1;
    private javax.swing.JLabel jdate;
    private javax.swing.JTextField jdate2;
    private javax.swing.JTextField jdate3;
    private javax.swing.JLabel jladdphoto;
    private javax.swing.JLabel jladdphoto1;
    private javax.swing.JLabel jtime;
    private javax.swing.JTextField jtime3;
    private javax.swing.JTextField jtime4;
    private javax.swing.JTextField price;
    private javax.swing.JTextField price1;
    private javax.swing.JTable reservationtab2;
    public static javax.swing.JTable reservationtab3;
    public static javax.swing.JTable reservationtab4;
    public static javax.swing.JTable reservationtab5;
    public static javax.swing.JTable reservationtab6;
    private javax.swing.JTextField searcfield;
    // End of variables declaration//GEN-END:variables

  

   

}